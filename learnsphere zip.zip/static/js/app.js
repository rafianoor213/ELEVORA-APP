/**
 * ELEVORA AI - Master Application Controller & Router
 * Powers the complete Learn-to-Prove-to-Earn interactive experience.
 */

class ElevoraApp {
  constructor() {
    this.apiBase = window.location.origin;
    this.isApiOnline = false;
    this.activeRoute = "landing";
    this.currentJudgeStep = 1;

    // Local cached state
    this.user = null;
    this.skills = [];
    this.readiness = null;
    this.jobs = [];
    this.roadmapStages = [];
    this.project = null;
    this.currentSubmission = null;
    this.applications = {};

    window.addEventListener("hashchange", () => this.handleHashChange());
  }

  async init() {
    // 1. Check Backend API Connectivity
    await this.checkApiStatus();

    // 2. Load State from API or LocalStore
    await this.loadInitialData();

    // 3. Route to URL hash or landing
    this.handleHashChange();

    // 4. Update status badge
    this.updateStatusBadge();
  }

  async checkApiStatus() {
    try {
      const res = await fetch(`${this.apiBase}/api/health`, { method: "GET" });
      if (res.ok) {
        const data = await res.json();
        this.isApiOnline = data.status === "healthy";
      } else {
        this.isApiOnline = false;
      }
    } catch (e) {
      this.isApiOnline = false;
    }
  }

  updateStatusBadge() {
    const badge = document.getElementById("backend-status-badge");
    if (!badge) return;
    if (this.isApiOnline) {
      badge.className = "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] bg-emerald-950/80 text-emerald-400 border border-emerald-500/30";
      badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Elevora API Connected`;
    } else {
      badge.className = "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] bg-amber-950/80 text-amber-300 border border-amber-500/30";
      badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Local Engine Active`;
    }
  }

  async loadInitialData() {
    if (this.isApiOnline) {
      try {
        const [profRes, projRes, jobsRes] = await Promise.all([
          fetch(`${this.apiBase}/api/profile`),
          fetch(`${this.apiBase}/api/projects`),
          fetch(`${this.apiBase}/api/market/jobs`)
        ]);

        if (profRes.ok) {
          const profData = await profRes.json();
          this.user = profData.user;
          this.skills = profData.user.skills || [];
          this.readiness = profData.user.readiness;
        }

        if (projRes.ok) {
          const projData = await projRes.json();
          this.project = projData.project;
          this.currentSubmission = projData.current_submission;
        }

        if (jobsRes.ok) {
          const jobsData = await jobsRes.json();
          this.jobs = jobsData.sample_listings || [];
        }
        return;
      } catch (e) {
        console.warn("Falling back to local store:", e);
      }
    }

    // Fallback to client-side store
    const store = window.elevoraStore;
    this.user = store.state.user;
    this.skills = store.state.skills;
    this.project = store.state.project;
    this.currentSubmission = store.state.project_submission;
    this.jobs = store.state.jobs;
    this.readiness = store.calculateReadiness();
  }

  handleHashChange() {
    const hash = window.location.hash.replace("#", "").trim();
    if (hash) {
      this.navigate(hash, false);
    } else {
      this.navigate("landing", false);
    }
  }

  navigate(route, updateHash = true) {
    this.activeRoute = route;
    if (updateHash) {
      window.location.hash = route;
    }

    const appContainer = document.getElementById("app");
    if (!appContainer) return;

    window.scrollTo({ top: 0, behavior: "smooth" });

    // Render corresponding view
    switch (route) {
      case "landing":
        appContainer.innerHTML = this.renderLanding();
        break;
      case "login":
        appContainer.innerHTML = this.renderAuth(false);
        break;
      case "register":
        appContainer.innerHTML = this.renderAuth(true);
        break;
      case "onboarding":
        appContainer.innerHTML = this.renderOnboarding();
        break;
      case "dashboard":
        appContainer.innerHTML = this.renderAppShell(this.renderDashboard());
        break;
      case "advisor":
        appContainer.innerHTML = this.renderAppShell(this.renderAdvisor());
        break;
      case "market":
        appContainer.innerHTML = this.renderAppShell(this.renderMarket());
        break;
      case "gap":
        appContainer.innerHTML = this.renderAppShell(this.renderGap());
        break;
      case "roadmap":
        appContainer.innerHTML = this.renderAppShell(this.renderRoadmap());
        break;
      case "project":
        appContainer.innerHTML = this.renderAppShell(this.renderProject());
        break;
      case "portfolio":
        appContainer.innerHTML = this.renderAppShell(this.renderPortfolio());
        break;
      case "opportunities":
        appContainer.innerHTML = this.renderAppShell(this.renderOpportunities());
        break;
      default:
        appContainer.innerHTML = this.renderLanding();
    }

    if (window.lucide) {
      lucide.createIcons();
    }
  }

  showToast(message, type = "success") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    const bgClass = type === "success" ? "bg-emerald-600 text-white" : type === "info" ? "bg-purple-600 text-white" : "bg-rose-600 text-white";
    const iconName = type === "success" ? "check-circle" : type === "info" ? "info" : "alert-circle";

    toast.className = `flex items-center gap-2 px-4 py-3 rounded-xl shadow-xl text-sm font-medium animate-fade-in pointer-events-auto ${bgClass}`;
    toast.innerHTML = `<i data-lucide="${iconName}" class="w-4 h-4"></i> <span>${message}</span>`;
    container.appendChild(toast);

    if (window.lucide) lucide.createIcons();

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
      toast.style.transition = "all 0.3s ease";
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // =========================================================================
  // VIEW RENDERERS
  // =========================================================================

  // 1. PUBLIC LANDING PAGE
  renderLanding() {
    return `
      <!-- Landing Navbar -->
      <header class="elevora-glass sticky top-11 z-40 border-b border-purple-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div class="flex items-center gap-3 cursor-pointer" onclick="app.navigate('landing')">
            <div class="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <i data-lucide="sparkles" class="w-5 h-5"></i>
            </div>
            <div>
              <span class="text-xl font-bold tracking-tight text-[#101426]">ELEVORA<span class="text-purple-600">.AI</span></span>
              <span class="block text-[10px] text-gray-500 font-semibold tracking-wider uppercase -mt-1">Career Platform</span>
            </div>
          </div>

          <nav class="hidden md:flex items-center gap-7 text-sm font-medium text-gray-600">
            <a href="#how-it-works" class="hover:text-purple-600 transition">How It Works</a>
            <a href="#pathway" class="hover:text-purple-600 transition">Learn-to-Prove-to-Earn</a>
            <a href="#features" class="hover:text-purple-600 transition">7 Core Features</a>
            <button onclick="app.navigate('market')" class="hover:text-purple-600 transition">Market Demand</button>
            <button onclick="app.navigate('opportunities')" class="hover:text-purple-600 transition">Opportunities</button>
          </nav>

          <div class="flex items-center gap-3">
            <button onclick="app.demoLogin()" class="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-purple-50 text-purple-700 hover:bg-purple-100 transition border border-purple-200">
              <i data-lucide="zap" class="w-3.5 h-3.5 text-purple-600"></i>
              Judge Demo Login
            </button>
            <button onclick="app.navigate('login')" class="px-4 py-2 text-xs font-semibold text-gray-700 hover:text-purple-600 transition">
              Sign In
            </button>
            <button onclick="app.navigate('onboarding')" class="gradient-primary text-white px-4 py-2 rounded-xl text-xs font-semibold shadow-md shadow-purple-600/20 hover:opacity-95 transition">
              Get Started Free
            </button>
          </div>
        </div>
      </header>

      <!-- Hero Section -->
      <section class="relative pt-12 pb-20 overflow-hidden bg-gradient-to-b from-purple-50/50 via-white to-[#F7F7FC]">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-100 text-purple-800 text-xs font-bold mb-6 border border-purple-200 shadow-sm">
            <span class="w-2 h-2 rounded-full bg-purple-600 animate-ping"></span>
            Turn Your Potential Into Opportunity &bull; LearnSphere AI Hackathon
          </div>

          <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#101426] tracking-tight max-w-4xl mx-auto leading-tight sm:leading-none">
            Stop guessing what to learn.<br>
            <span class="gradient-text">Start building the skills</span> that move your career forward.
          </h1>

          <p class="mt-6 text-base sm:text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Your career journey, powered by AI. Discover the skills employers need, follow a personalized roadmap, prove your abilities with practical projects, and find opportunities that match your potential.
          </p>

          <div class="mt-8 flex flex-wrap justify-center gap-4">
            <button onclick="app.demoLogin()" class="gradient-primary text-white px-7 py-3.5 rounded-xl font-bold shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:-translate-y-0.5 transition flex items-center gap-2">
              <i data-lucide="play" class="w-4 h-4 fill-white"></i>
              Start Your Journey (1-Click Demo)
            </button>
            <a href="#pathway" class="bg-white text-gray-700 px-6 py-3.5 rounded-xl font-semibold border border-gray-200 hover:border-purple-300 hover:bg-purple-50/50 transition flex items-center gap-2">
              Explore How It Works
              <i data-lucide="arrow-down" class="w-4 h-4 text-purple-600"></i>
            </a>
          </div>

          <!-- Quick Demo Banner for Judges -->
          <div class="mt-10 max-w-2xl mx-auto p-3.5 rounded-2xl bg-white/90 border border-purple-200/80 shadow-md flex items-center justify-between gap-3 text-left">
            <div class="flex items-center gap-3">
              <div class="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                CSE
              </div>
              <div>
                <p class="text-xs font-bold text-gray-900">Pre-Configured Hackathon Demo User: Alex Chen</p>
                <p class="text-[11px] text-gray-500">Target Role: Frontend Developer &bull; Initial Skills: HTML/CSS &bull; Capstone Ready</p>
              </div>
            </div>
            <button onclick="app.runJudgeStep(1)" class="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold transition whitespace-nowrap shadow-sm">
              Launch Walkthrough &rarr;
            </button>
          </div>
        </div>
      </section>

      <!-- 2. THE MAIN DIFFERENTIATOR — LEARN-TO-PROVE-TO-EARN PATHWAY -->
      <section id="pathway" class="py-16 bg-white border-y border-purple-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="text-center max-w-3xl mx-auto mb-14">
            <span class="text-xs font-bold uppercase tracking-wider text-purple-600">The Elevora AI X-Factor</span>
            <h2 class="text-3xl font-extrabold text-[#101426] mt-2">The Learn-to-Prove-to-Earn Pathway</h2>
            <p class="text-gray-600 mt-3 text-sm sm:text-base">
              Learning platforms, project tools, and job boards operate separately. Elevora AI connects them into one guided career progression where each milestone unlocks the next.
            </p>
          </div>

          <!-- 3 Connected Stages -->
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            <!-- Stage 1: LEARN -->
            <div class="elevora-card p-6 border-t-4 border-t-purple-500 relative">
              <div class="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-4 font-bold text-lg">
                01
              </div>
              <span class="text-xs font-bold uppercase tracking-wider text-purple-600">Stage One</span>
              <h3 class="text-xl font-bold text-[#101426] mt-1 mb-2">LEARN</h3>
              <p class="text-xs text-gray-600 leading-relaxed">
                Discover real job-market requirements, pinpoint your skill gaps, and follow a personalized roadmap with genuine documentation and structured practice.
              </p>
              <div class="mt-4 pt-4 border-t border-gray-100 space-y-1.5 text-xs text-gray-500">
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Job-Market Skill Analysis</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> AI Skill-Gap Diagnosis</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Free Genuine Resources (MDN, React)</div>
              </div>
            </div>

            <!-- Stage 2: PROVE -->
            <div class="elevora-card p-6 border-t-4 border-t-violet relative shadow-lg">
              <div class="w-12 h-12 rounded-xl bg-violet/20 text-purple-900 flex items-center justify-center mb-4 font-bold text-lg">
                02
              </div>
              <div class="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-purple-600 text-white uppercase tracking-wider mb-1">
                The X-Factor Core
              </div>
              <h3 class="text-xl font-bold text-[#101426] mb-2">PROVE</h3>
              <p class="text-xs text-gray-600 leading-relaxed">
                Tutorials don't convince employers. Complete practical capstone assignments evaluated against transparent 6-criteria rubrics by AI to demonstrate competence.
              </p>
              <div class="mt-4 pt-4 border-t border-gray-100 space-y-1.5 text-xs text-gray-500">
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Interactive Capstone Project</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> 6-Criteria Rubric Scoring (/60)</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Verified Skills Upgrade</div>
              </div>
            </div>

            <!-- Stage 3: EARN -->
            <div class="elevora-card p-6 border-t-4 border-t-success relative">
              <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4 font-bold text-lg">
                03
              </div>
              <span class="text-xs font-bold uppercase tracking-wider text-emerald-600">Stage Three</span>
              <h3 class="text-xl font-bold text-[#101426] mt-1 mb-2">EARN</h3>
              <p class="text-xs text-gray-600 leading-relaxed">
                Connect your proven skill profile to matched entry-level roles and internships. Watch match percentages jump as you verify required technologies.
              </p>
              <div class="mt-4 pt-4 border-t border-gray-100 space-y-1.5 text-xs text-gray-500">
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Dynamic Match Percentage Math</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> Public Verified Portfolio</div>
                <div class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i> One-Click Application Pathway</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Problem & Solution Section -->
      <section class="py-16 bg-[#F7F7FC]">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <!-- Problem -->
            <div class="p-8 rounded-2xl bg-rose-50/70 border border-rose-200">
              <div class="w-10 h-10 rounded-xl bg-rose-200 text-rose-800 flex items-center justify-center font-bold mb-4">
                <i data-lucide="x-circle" class="w-5 h-5"></i>
              </div>
              <h3 class="text-2xl font-bold text-rose-950 mb-3">The Fragmented Trap Students Face</h3>
              <ul class="space-y-3 text-xs sm:text-sm text-rose-900 leading-relaxed">
                <li class="flex items-start gap-2">
                  <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 mt-0.5 shrink-0"></i>
                  <span><strong>Tutorial Hell:</strong> Students consume hundreds of hours of video courses without understanding what employers actually require.</span>
                </li>
                <li class="flex items-start gap-2">
                  <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 mt-0.5 shrink-0"></i>
                  <span><strong>Unverified Resumes:</strong> Claiming skills like "JavaScript" on a resume carries little weight without proof of implementation.</span>
                </li>
                <li class="flex items-start gap-2">
                  <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-600 mt-0.5 shrink-0"></i>
                  <span><strong>Disconnected Job Portals:</strong> Job boards reject students without explaining which missing skills would make them competitive.</span>
                </li>
              </ul>
            </div>

            <!-- Solution -->
            <div class="p-8 rounded-2xl bg-purple-50/70 border border-purple-200">
              <div class="w-10 h-10 rounded-xl bg-purple-200 text-purple-900 flex items-center justify-center font-bold mb-4">
                <i data-lucide="check-circle" class="w-5 h-5 text-purple-700"></i>
              </div>
              <h3 class="text-2xl font-bold text-purple-950 mb-3">The Elevora AI Connected Solution</h3>
              <ul class="space-y-3 text-xs sm:text-sm text-purple-950 leading-relaxed">
                <li class="flex items-start gap-2">
                  <i data-lucide="zap" class="w-4 h-4 text-purple-600 mt-0.5 shrink-0"></i>
                  <span><strong>Live Market Grounding:</strong> Roadmaps are derived directly from actual job listings, teaching high-demand skills first.</span>
                </li>
                <li class="flex items-start gap-2">
                  <i data-lucide="shield-check" class="w-4 h-4 text-purple-600 mt-0.5 shrink-0"></i>
                  <span><strong>Demonstrated & Verified:</strong> Capstone projects evaluated via transparent rubrics upgrade skills from "claimed" to "proven".</span>
                </li>
                <li class="flex items-start gap-2">
                  <i data-lucide="trending-up" class="w-4 h-4 text-purple-600 mt-0.5 shrink-0"></i>
                  <span><strong>Dynamic Progression:</strong> As your projects are verified, your career readiness score jumps and matched opportunities update!</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <!-- 7 Core Features Overview -->
      <section id="features" class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="text-center max-w-3xl mx-auto mb-14">
            <span class="text-xs font-bold uppercase tracking-wider text-purple-600">Comprehensive Suite</span>
            <h2 class="text-3xl font-extrabold text-[#101426] mt-2">Seven Connected AI-Powered Modules</h2>
            <p class="text-gray-600 mt-3 text-sm">
              Each module shares the same student profile, skills, and progress state—creating a cohesive journey from first lesson to job offer.
            </p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- 1. AI Career Advisor -->
            <div onclick="app.navigate('advisor')" class="elevora-card p-6 cursor-pointer hover:border-purple-400">
              <div class="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-3">
                <i data-lucide="bot" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">1. AI Career Advisor</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Interactive guidance analyzing your background, answering target role questions, and outlining realistic next steps.
              </p>
            </div>

            <!-- 2. Job Market Analyzer -->
            <div onclick="app.navigate('market')" class="elevora-card p-6 cursor-pointer hover:border-purple-400">
              <div class="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-3">
                <i data-lucide="bar-chart-3" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">2. Job Market Analyzer</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Curated dataset analyzing skill frequency across benchmark vacancies to distinguish essential requirements from preferred skills.
              </p>
            </div>

            <!-- 3. AI Skill-Gap Analyzer -->
            <div onclick="app.navigate('gap')" class="elevora-card p-6 cursor-pointer hover:border-purple-400">
              <div class="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-3">
                <i data-lucide="git-pull-request" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">3. AI Skill-Gap Analyzer</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Compares your current abilities against target standards with transparent weighted formulas and priority rankings.
              </p>
            </div>

            <!-- 4. Personalized Learning Roadmap -->
            <div onclick="app.navigate('roadmap')" class="elevora-card p-6 cursor-pointer hover:border-purple-400">
              <div class="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-3">
                <i data-lucide="map" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">4. Personalized Roadmap</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Structured 5-stage curriculum with direct links to free high-quality documentation (MDN, freeCodeCamp, React docs).
              </p>
            </div>

            <!-- 5. Practical Project & Skill Evaluator -->
            <div onclick="app.navigate('project')" class="elevora-card p-6 cursor-pointer hover:border-purple-400 bg-purple-50/30">
              <div class="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center mb-3">
                <i data-lucide="code-2" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">5. Project & Evaluator</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Interactive Capstone Project with automated 6-rubric grading (/60), constructive feedback, and verified skill badges.
              </p>
            </div>

            <!-- 6. Portfolio & Skill Profile -->
            <div onclick="app.navigate('portfolio')" class="elevora-card p-6 cursor-pointer hover:border-purple-400">
              <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3">
                <i data-lucide="user-check" class="w-5 h-5"></i>
              </div>
              <h4 class="font-bold text-[#101426] text-base mb-1">6. Portfolio & Profile</h4>
              <p class="text-xs text-gray-600 leading-relaxed">
                Public-ready verified profile separating self-reported skills from demonstrated and rubric-evaluated achievements.
              </p>
            </div>

            <!-- 7. Opportunity Matching Dashboard -->
            <div onclick="app.navigate('opportunities')" class="elevora-card p-6 cursor-pointer hover:border-purple-400 md:col-span-2 lg:col-span-3">
              <div class="flex items-start gap-4">
                <div class="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                  <i data-lucide="briefcase" class="w-5 h-5"></i>
                </div>
                <div>
                  <h4 class="font-bold text-[#101426] text-base mb-1">7. Opportunity Matching Dashboard</h4>
                  <p class="text-xs text-gray-600 leading-relaxed">
                    Matches you with entry-level vacancies and internships where match percentages dynamically reflect both your known skills and your completed project evaluations.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Final Call to Action -->
      <section class="py-16 bg-gradient-to-r from-[#101426] via-[#1c223d] to-[#101426] text-white text-center">
        <div class="max-w-4xl mx-auto px-4">
          <h2 class="text-3xl font-extrabold mb-4">Ready to Prove What You Can Do?</h2>
          <p class="text-purple-200 text-sm max-w-xl mx-auto mb-8">
            Experience the complete Learn-to-Prove-to-Earn pathway designed for the LearnSphere AI Hackathon.
          </p>
          <div class="flex flex-wrap justify-center gap-4">
            <button onclick="app.demoLogin()" class="gradient-primary text-white px-8 py-3.5 rounded-xl font-bold shadow-lg shadow-purple-600/30 hover:opacity-95 transition">
              Explore Demo as Alex Chen
            </button>
            <button onclick="app.navigate('onboarding')" class="bg-white/10 text-white px-6 py-3.5 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition">
              Create New Profile
            </button>
          </div>
        </div>
      </section>

      <!-- Footer -->
      <footer class="bg-white border-t border-gray-200 py-10 text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div class="flex items-center gap-2">
            <span class="font-bold text-gray-900 text-sm">ELEVORA AI</span>
            <span>&bull; LearnSphere AI Hackathon 2026 Prototype</span>
          </div>
          <div class="flex items-center gap-6">
            <a href="#how-it-works" class="hover:text-purple-600">How It Works</a>
            <a href="#pathway" class="hover:text-purple-600">Pathway</a>
            <button onclick="app.navigate('dashboard')" class="hover:text-purple-600">Demo Dashboard</button>
            <button onclick="app.resetDemoData()" class="text-rose-500 hover:text-rose-700">Reset Demo</button>
          </div>
        </div>
      </footer>
    `;
  }

  // 2. AUTHENTICATION (SIGN IN / SIGN UP)
  renderAuth(isRegister = false) {
    return `
      <div class="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-gradient-to-b from-purple-50/40 to-[#F7F7FC]">
        <div class="elevora-card max-w-md w-full p-8 shadow-xl">
          <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-xl gradient-primary text-white flex items-center justify-center mx-auto mb-3 shadow-md">
              <i data-lucide="sparkles" class="w-6 h-6"></i>
            </div>
            <h2 class="text-2xl font-extrabold text-[#101426]">${isRegister ? 'Create Your Account' : 'Welcome Back'}</h2>
            <p class="text-xs text-gray-500 mt-1">Start your Learn-to-Prove-to-Earn career pathway</p>
          </div>

          <!-- Judge 1-Click Fast Login -->
          <div class="mb-6 p-3 rounded-xl bg-purple-50 border border-purple-200 text-center">
            <p class="text-[11px] font-semibold text-purple-900 mb-2">Hackathon Judges & Evaluators:</p>
            <button onclick="app.demoLogin()" class="w-full gradient-primary text-white text-xs font-bold py-2.5 rounded-lg shadow-sm hover:opacity-95 transition flex items-center justify-center gap-1.5">
              <i data-lucide="zap" class="w-3.5 h-3.5"></i>
              Instant Demo Login (Alex Chen)
            </button>
          </div>

          <div class="relative flex items-center justify-center mb-6">
            <div class="border-t border-gray-200 w-full"></div>
            <span class="bg-white px-3 text-[11px] text-gray-400 uppercase font-semibold">Or with email</span>
          </div>

          <form onsubmit="app.handleAuthSubmit(event, ${isRegister})" class="space-y-4">
            ${isRegister ? `
              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
                <input type="text" id="auth-name" required placeholder="e.g. Jordan Smith" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 focus:outline-none focus:border-purple-600 focus:ring-1 focus:ring-purple-600">
              </div>
            ` : ''}

            <div>
              <label class="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
              <input type="email" id="auth-email" required placeholder="you@university.edu" value="${isRegister ? '' : 'demo@elevora.ai'}" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 focus:outline-none focus:border-purple-600 focus:ring-1 focus:ring-purple-600">
            </div>

            <div>
              <label class="block text-xs font-semibold text-gray-700 mb-1">Password</label>
              <input type="password" id="auth-password" required placeholder="••••••••" value="${isRegister ? '' : 'elevora2026'}" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 focus:outline-none focus:border-purple-600 focus:ring-1 focus:ring-purple-600">
            </div>

            <button type="submit" class="w-full bg-[#101426] hover:bg-[#1c223d] text-white py-2.5 rounded-lg text-xs font-bold transition">
              ${isRegister ? 'Create Account & Continue' : 'Sign In to Elevora'}
            </button>
          </form>

          <div class="text-center mt-6 text-xs text-gray-500">
            ${isRegister ? `
              Already have an account? <button onclick="app.navigate('login')" class="text-purple-600 font-semibold hover:underline">Sign In</button>
            ` : `
              New to Elevora? <button onclick="app.navigate('register')" class="text-purple-600 font-semibold hover:underline">Create an Account</button>
            `}
          </div>
        </div>
      </div>
    `;
  }

  // 3. ONBOARDING WIZARD
  renderOnboarding() {
    return `
      <div class="min-h-[85vh] py-12 px-4 bg-gradient-to-b from-purple-50/30 to-[#F7F7FC]">
        <div class="max-w-2xl mx-auto elevora-card p-8 shadow-xl">
          <div class="mb-8">
            <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Step-by-Step Calibration</span>
            <h2 class="text-2xl font-extrabold text-[#101426] mt-1">Setup Your Career Profile</h2>
            <p class="text-xs text-gray-500 mt-1">Elevora AI uses these parameters to identify skill gaps and generate your custom roadmap.</p>
          </div>

          <form onsubmit="app.handleOnboardingSubmit(event)" class="space-y-6">
            <!-- 1. Target Career -->
            <div class="p-4 rounded-xl bg-purple-50/50 border border-purple-200">
              <label class="block text-xs font-bold text-gray-800 uppercase tracking-wider mb-2">1. Target Career Track</label>
              <select id="onb-career" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 bg-white font-medium focus:ring-1 focus:ring-purple-600">
                <option value="Frontend Developer" selected>Frontend Developer (MVP Career Focus)</option>
                <option value="Full-Stack Engineer" disabled>Full-Stack Engineer (Coming Soon)</option>
                <option value="UI/UX Engineer" disabled>UI/UX Engineer (Coming Soon)</option>
              </select>
              <p class="text-[11px] text-gray-500 mt-1">Frontend Developer is fully populated with benchmark listings, roadmaps, and capstone evaluations.</p>
            </div>

            <!-- 2. Academic & Experience Level -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Education Level</label>
                <input type="text" id="onb-edu" value="B.Sc. in Computer Science (3rd Year)" required class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Current Status</label>
                <select id="onb-status" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 bg-white">
                  <option value="Undergraduate Student" selected>Undergraduate Student</option>
                  <option value="Fresh Graduate">Fresh Graduate</option>
                  <option value="Career Transitioner">Career Transitioner</option>
                </select>
              </div>
            </div>

            <!-- 3. Existing Skills Preselection -->
            <div>
              <label class="block text-xs font-bold text-gray-800 uppercase tracking-wider mb-2">3. Select Your Current Skills</label>
              <p class="text-[11px] text-gray-500 mb-3">Be honest! Missing skills will be transformed into high-priority roadmap lessons.</p>
              <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="HTML5" checked class="text-purple-600 rounded">
                  <span>HTML5</span>
                </label>
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="CSS3" checked class="text-purple-600 rounded">
                  <span>CSS3</span>
                </label>
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="Responsive Design" checked class="text-purple-600 rounded">
                  <span>Responsive Design</span>
                </label>
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="JavaScript" class="text-purple-600 rounded">
                  <span>JavaScript</span>
                </label>
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="Git & GitHub" class="text-purple-600 rounded">
                  <span>Git & GitHub</span>
                </label>
                <label class="flex items-center gap-2 p-2.5 rounded-lg border border-gray-200 hover:bg-purple-50/50 cursor-pointer">
                  <input type="checkbox" name="skills" value="React" class="text-purple-600 rounded">
                  <span>React</span>
                </label>
              </div>
            </div>

            <!-- 4. Weekly Time Commitment -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Weekly Learning Time (Hours)</label>
                <input type="number" id="onb-hours" min="4" max="40" value="14" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Learning Preference</label>
                <select id="onb-style" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 bg-white">
                  <option selected>Practical Projects & Hands-On Code</option>
                  <option>Visual Documentation & Interactive Guides</option>
                  <option>Balanced Structured Curriculum</option>
                </select>
              </div>
            </div>

            <button type="submit" class="w-full gradient-primary text-white py-3 rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition">
              Generate Personalized Career Dashboard &rarr;
            </button>
          </form>
        </div>
      </div>
    `;
  }

  // APP SHELL (AUTHENTICATED SIDEBAR & TOP BAR)
  renderAppShell(viewHtml) {
    const r = this.readiness || { overall_score: 45, stage: "LEARN" };
    const navItems = [
      { id: "dashboard", label: "Dashboard", icon: "layout-dashboard" },
      { id: "advisor", label: "AI Career Advisor", icon: "bot" },
      { id: "market", label: "Job Market Analyzer", icon: "bar-chart-2" },
      { id: "gap", label: "AI Skill-Gap Analyzer", icon: "git-pull-request" },
      { id: "roadmap", label: "Learning Roadmap", icon: "map" },
      { id: "project", label: "Practical Capstone", icon: "code-2" },
      { id: "portfolio", label: "Portfolio & Profile", icon: "user-check" },
      { id: "opportunities", label: "Opportunities", icon: "briefcase" }
    ];

    return `
      <div class="flex-1 flex flex-col md:flex-row min-h-[calc(100vh-45px)]">
        <!-- Sidebar Navigation -->
        <aside class="w-full md:w-64 bg-white border-r border-gray-200 flex flex-col shrink-0">
          <!-- Sidebar Brand -->
          <div class="p-4 border-b border-gray-100 flex items-center justify-between">
            <div class="flex items-center gap-2 cursor-pointer" onclick="app.navigate('dashboard')">
              <div class="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center text-white shadow-sm">
                <i data-lucide="sparkles" class="w-4 h-4"></i>
              </div>
              <span class="font-bold text-[#101426] tracking-tight">ELEVORA<span class="text-purple-600">.AI</span></span>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700">MVP</span>
          </div>

          <!-- Active User Badge -->
          <div class="p-3.5 mx-3 mt-3 rounded-xl bg-purple-50/60 border border-purple-100">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-full gradient-primary text-white flex items-center justify-center font-bold text-xs shrink-0">
                ${(this.user?.full_name || 'A').charAt(0)}
              </div>
              <div class="overflow-hidden">
                <p class="text-xs font-bold text-gray-900 truncate">${this.user?.full_name || 'Alex Chen'}</p>
                <p class="text-[10px] text-purple-600 font-semibold truncate">${this.user?.target_career || 'Frontend Developer'}</p>
              </div>
            </div>
          </div>

          <!-- Navigation Links -->
          <nav class="p-3 space-y-1 flex-1 overflow-y-auto">
            ${navItems.map(item => `
              <button onclick="app.navigate('${item.id}')" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition ${this.activeRoute === item.id ? 'nav-active shadow-sm' : 'text-gray-600 hover:bg-gray-50'}">
                <i data-lucide="${item.icon}" class="w-4 h-4 ${this.activeRoute === item.id ? 'text-purple-600' : 'text-gray-400'}"></i>
                <span>${item.label}</span>
              </button>
            `).join('')}
          </nav>

          <!-- Sidebar Footer with Learn-Prove-Earn Mini Status -->
          <div class="p-3 border-t border-gray-100 bg-gray-50/50">
            <div class="flex items-center justify-between text-[11px] mb-1 font-semibold text-gray-600">
              <span>Readiness Stage:</span>
              <span class="text-purple-600 font-bold">${r.stage}</span>
            </div>
            <div class="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
              <div class="gradient-primary h-full rounded-full transition-all duration-500" style="width: ${r.overall_score}%"></div>
            </div>
          </div>
        </aside>

        <!-- Main Content View Area -->
        <main class="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          ${viewHtml}
        </main>
      </div>
    `;
  }

  // 4. MAIN USER DASHBOARD
  renderDashboard() {
    const r = this.readiness || { overall_score: 55, lessons_completed: 2, total_lessons: 8, roadmap_progress_percentage: 25, stage: "LEARN" };
    const gap = window.elevoraStore ? window.elevoraStore.calculateSkillGap() : { match_percentage: 60 };

    return `
      <div class="max-w-7xl mx-auto space-y-6">
        <!-- Welcome Banner -->
        <div class="elevora-card p-6 bg-gradient-to-r from-purple-900 via-indigo-900 to-[#101426] text-white relative overflow-hidden">
          <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/30 text-purple-200 text-[11px] font-semibold mb-2">
                <i data-lucide="target" class="w-3 h-3"></i> Target Role: ${this.user?.target_career || 'Frontend Developer'}
              </div>
              <h1 class="text-2xl sm:text-3xl font-extrabold tracking-tight">Welcome back, ${this.user?.full_name || 'Alex'}!</h1>
              <p class="text-purple-200 text-xs sm:text-sm mt-1 max-w-xl">
                Your career journey is actively calibrated against 5 industry benchmark vacancies. Follow your personalized roadmap to elevate your score.
              </p>
            </div>
            <button onclick="app.navigate('roadmap')" class="gradient-primary px-4 py-2.5 rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition whitespace-nowrap self-start md:self-auto">
              Continue Roadmap &rarr;
            </button>
          </div>
        </div>

        <!-- Visual Learn -> Prove -> Earn Progress Tracker -->
        <div class="elevora-card p-6">
          <div class="flex items-center justify-between mb-4">
            <div>
              <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider">Learn-to-Prove-to-Earn Pathway Status</h3>
              <p class="text-xs text-gray-500">Each completed stage directly influences your readiness and unlocks matched roles.</p>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-bold ${r.stage === 'EARN' ? 'bg-emerald-100 text-emerald-800' : r.stage === 'PROVE' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}">
              Current Stage: ${r.stage}
            </span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <!-- Stage 1: LEARN -->
            <div class="p-4 rounded-xl border ${r.stage === 'LEARN' ? 'border-purple-500 bg-purple-50/40 ring-2 ring-purple-500/20' : 'border-gray-200 bg-gray-50'}">
              <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-bold text-purple-600">01 / LEARN</span>
                <i data-lucide="${r.roadmap_progress_percentage >= 50 ? 'check-circle' : 'circle-dashed'}" class="w-4 h-4 ${r.roadmap_progress_percentage >= 50 ? 'text-emerald-500' : 'text-purple-500'}"></i>
              </div>
              <h4 class="text-sm font-bold text-gray-900 mb-1">Skill Roadmap</h4>
              <p class="text-xs text-gray-500 mb-3">${r.lessons_completed}/${r.total_lessons} lessons completed</p>
              <div class="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                <div class="bg-purple-600 h-full rounded-full" style="width: ${r.roadmap_progress_percentage}%"></div>
              </div>
            </div>

            <!-- Stage 2: PROVE -->
            <div class="p-4 rounded-xl border ${r.stage === 'PROVE' ? 'border-purple-500 bg-purple-50/40 ring-2 ring-purple-500/20' : 'border-gray-200 bg-gray-50'}">
              <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-bold text-violet">02 / PROVE</span>
                <i data-lucide="${this.currentSubmission ? 'check-circle' : 'code-2'}" class="w-4 h-4 ${this.currentSubmission ? 'text-emerald-500' : 'text-gray-400'}"></i>
              </div>
              <h4 class="text-sm font-bold text-gray-900 mb-1">Practical Capstone</h4>
              <p class="text-xs text-gray-500 mb-3">${this.currentSubmission ? `Graded: ${this.currentSubmission.grade}` : 'Pending Submission'}</p>
              <div class="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                <div class="bg-violet h-full rounded-full" style="width: ${this.currentSubmission ? 100 : 25}%"></div>
              </div>
            </div>

            <!-- Stage 3: EARN -->
            <div class="p-4 rounded-xl border ${r.stage === 'EARN' ? 'border-emerald-500 bg-emerald-50/40 ring-2 ring-emerald-500/20' : 'border-gray-200 bg-gray-50'}">
              <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-bold text-emerald-600">03 / EARN</span>
                <i data-lucide="briefcase" class="w-4 h-4 ${r.stage === 'EARN' ? 'text-emerald-500' : 'text-gray-400'}"></i>
              </div>
              <h4 class="text-sm font-bold text-gray-900 mb-1">Opportunity Matching</h4>
              <p class="text-xs text-gray-500 mb-3">${r.stage === 'EARN' ? 'High-Match Internships Unlocked' : 'Requires Proven Project'}</p>
              <div class="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full" style="width: ${r.stage === 'EARN' ? 100 : 30}%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- 4 Key Metrics Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <!-- Readiness Indicator -->
          <div class="elevora-card p-5">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-gray-500">Career Readiness</span>
              <div class="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center">
                <i data-lucide="gauge" class="w-4 h-4"></i>
              </div>
            </div>
            <div class="text-3xl font-extrabold text-[#101426]">${r.overall_score}%</div>
            <p class="text-[11px] text-gray-500 mt-1">Weighted: 50% knowledge + 50% proven code</p>
          </div>

          <!-- Market Match Score -->
          <div class="elevora-card p-5">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-gray-500">Skill Match Score</span>
              <div class="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                <i data-lucide="git-merge" class="w-4 h-4"></i>
              </div>
            </div>
            <div class="text-3xl font-extrabold text-indigo-700">${gap.match_percentage}%</div>
            <p class="text-[11px] text-gray-500 mt-1">Based on 5 curated vacancies</p>
          </div>

          <!-- Roadmap Progress -->
          <div class="elevora-card p-5">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-gray-500">Roadmap Completed</span>
              <div class="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                <i data-lucide="book-open" class="w-4 h-4"></i>
              </div>
            </div>
            <div class="text-3xl font-extrabold text-amber-800">${r.lessons_completed}/${r.total_lessons}</div>
            <p class="text-[11px] text-gray-500 mt-1">${r.roadmap_progress_percentage}% curriculum progress</p>
          </div>

          <!-- Completed Projects -->
          <div class="elevora-card p-5">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-gray-500">Verified Projects</span>
              <div class="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <i data-lucide="award" class="w-4 h-4"></i>
              </div>
            </div>
            <div class="text-3xl font-extrabold text-emerald-700">${this.currentSubmission ? 1 : 0}</div>
            <p class="text-[11px] text-gray-500 mt-1">${this.currentSubmission ? 'Capstone Evaluated' : 'None yet'}</p>
          </div>
        </div>

        <!-- Two Column Deep Dive: Skills & Quick Actions -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Skill Breakdown Card (2 cols) -->
          <div class="elevora-card p-6 lg:col-span-2">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider">Current Skills Inventory</h3>
              <button onclick="app.navigate('gap')" class="text-xs text-purple-600 font-semibold hover:underline">View Gap Analysis &rarr;</button>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              ${this.skills.map(s => `
                <div class="p-3 rounded-xl border border-gray-200 flex items-center justify-between">
                  <div>
                    <span class="text-xs font-bold text-gray-900">${s.skill_name}</span>
                    <span class="block text-[10px] text-gray-500 capitalize">Source: ${s.source || 'Curated'}</span>
                  </div>
                  <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${s.status === 'demonstrated' ? 'badge-demonstrated' : 'badge-in-progress'}">
                    ${s.status === 'demonstrated' ? 'Proven via Project' : 'In Progress'}
                  </span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Quick Action Card (1 col) -->
          <div class="elevora-card p-6 flex flex-col justify-between">
            <div>
              <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Recommended Next Step</h3>
              ${!this.currentSubmission ? `
                <div class="p-3.5 rounded-xl bg-purple-50 border border-purple-200 mb-4">
                  <div class="flex items-center gap-2 text-xs font-bold text-purple-900 mb-1">
                    <i data-lucide="code" class="w-4 h-4 text-purple-600"></i>
                    Capstone Ready for Submission
                  </div>
                  <p class="text-[11px] text-gray-600 leading-relaxed">
                    Submit your Interactive Task Management Web App to prove your JavaScript skills and boost your job match score!
                  </p>
                </div>
                <button onclick="app.navigate('project')" class="w-full gradient-primary text-white py-2.5 rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition">
                  Go to Capstone Evaluator &rarr;
                </button>
              ` : `
                <div class="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 mb-4">
                  <div class="flex items-center gap-2 text-xs font-bold text-emerald-900 mb-1">
                    <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600"></i>
                    Capstone Verified! (Score: ${this.currentSubmission.percentage}%)
                  </div>
                  <p class="text-[11px] text-gray-600 leading-relaxed">
                    You have unlocked high-match internship opportunities matching your proven abilities.
                  </p>
                </div>
                <button onclick="app.navigate('opportunities')" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-xs font-bold shadow-md transition">
                  View Matched Jobs &rarr;
                </button>
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // 5. AI CAREER ADVISOR VIEW
  renderAdvisor() {
    return `
      <div class="max-w-4xl mx-auto space-y-6">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 1</span>
          <h2 class="text-2xl font-extrabold text-[#101426]">AI Career Advisor</h2>
          <p class="text-xs text-gray-500 mt-1">Ask questions regarding market expectations, career transitions, and practical next steps.</p>
        </div>

        <!-- Chat Stream -->
        <div class="elevora-card p-6 min-h-[420px] flex flex-col justify-between">
          <div id="advisor-messages" class="space-y-4 overflow-y-auto max-h-[500px] pr-2">
            <!-- Initial Greeting -->
            <div class="flex items-start gap-3">
              <div class="w-8 h-8 rounded-lg gradient-primary text-white flex items-center justify-center shrink-0">
                <i data-lucide="bot" class="w-4 h-4"></i>
              </div>
              <div class="p-4 rounded-2xl bg-gray-50 border border-gray-200 text-xs sm:text-sm text-gray-800 max-w-2xl leading-relaxed">
                <p class="font-bold text-gray-900 mb-1">Elevora AI Career Advisor</p>
                Hello ${this.user?.full_name || 'Alex'}! I have reviewed your current profile targeting <strong>${this.user?.target_career || 'Frontend Developer'}</strong>. You currently possess foundational HTML/CSS skills. How can I guide your preparation today?
              </div>
            </div>
          </div>

          <!-- Quick Suggestion Chips -->
          <div class="mt-4 pt-4 border-t border-gray-100">
            <p class="text-[11px] font-semibold text-gray-500 mb-2">Suggested prompts:</p>
            <div class="flex flex-wrap gap-2">
              <button onclick="app.sendAdvisorQuery('What skills do entry-level frontend devs actually need in 2026?')" class="px-2.5 py-1.5 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 transition text-[11px] font-medium border border-purple-200">
                What skills do entry-level frontend devs need in 2026?
              </button>
              <button onclick="app.sendAdvisorQuery('How do I prove JavaScript skills without prior work experience?')" class="px-2.5 py-1.5 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 transition text-[11px] font-medium border border-purple-200">
                How do I prove JavaScript without prior work experience?
              </button>
              <button onclick="app.sendAdvisorQuery('Explain my current skill gaps for Junior Frontend roles.')" class="px-2.5 py-1.5 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 transition text-[11px] font-medium border border-purple-200">
                Explain my current skill gaps
              </button>
            </div>

            <!-- Input Bar -->
            <form onsubmit="app.handleAdvisorSubmit(event)" class="mt-3 flex items-center gap-2">
              <input type="text" id="advisor-input" placeholder="Type your career question..." class="flex-1 px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:outline-none focus:border-purple-600 focus:ring-1 focus:ring-purple-600">
              <button type="submit" id="advisor-send-btn" class="gradient-primary text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition flex items-center gap-1.5">
                <span>Send</span>
                <i data-lucide="send" class="w-3.5 h-3.5"></i>
              </button>
            </form>
          </div>
        </div>
      </div>
    `;
  }

  // 6. JOB MARKET ANALYZER VIEW
  renderMarket() {
    return `
      <div class="max-w-6xl mx-auto space-y-6">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 2</span>
          <h2 class="text-2xl font-extrabold text-[#101426]">Job Market Analyzer</h2>
          <p class="text-xs text-gray-500 mt-1">Aggregated skills data from curated entry-level job descriptions.</p>
        </div>

        <!-- Disclaimer Banner -->
        <div class="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2.5">
          <i data-lucide="info" class="w-4 h-4 text-amber-600 shrink-0"></i>
          <span><strong>Transparency Disclosure:</strong> Listings below are curated industry benchmarks used for prototype analysis and hackathon demonstration.</span>
        </div>

        <!-- Market Demand Analytics Breakdown -->
        <div class="elevora-card p-6">
          <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4">Required Technical Skills in Demand</h3>
          <div class="space-y-3">
            <div>
              <div class="flex justify-between text-xs font-semibold text-gray-700 mb-1">
                <span>JavaScript (ES6+, DOM, Fetch)</span>
                <span>100% of analyzed vacancies</span>
              </div>
              <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div class="bg-purple-600 h-full rounded-full" style="width: 100%"></div>
              </div>
            </div>
            <div>
              <div class="flex justify-between text-xs font-semibold text-gray-700 mb-1">
                <span>HTML5 & Responsive CSS Layouts</span>
                <span>100% of analyzed vacancies</span>
              </div>
              <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div class="bg-purple-600 h-full rounded-full" style="width: 100%"></div>
              </div>
            </div>
            <div>
              <div class="flex justify-between text-xs font-semibold text-gray-700 mb-1">
                <span>Git & GitHub (Branching, PRs)</span>
                <span>80% of analyzed vacancies</span>
              </div>
              <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div class="bg-violet h-full rounded-full" style="width: 80%"></div>
              </div>
            </div>
            <div>
              <div class="flex justify-between text-xs font-semibold text-gray-700 mb-1">
                <span>React / Component Architecture</span>
                <span>60% of analyzed vacancies</span>
              </div>
              <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div class="bg-indigo-500 h-full rounded-full" style="width: 60%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Benchmark Job Listings -->
        <div class="space-y-4">
          <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider">Curated Benchmark Vacancies</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            ${this.jobs.map(job => `
              <div class="elevora-card p-5">
                <div class="flex items-start justify-between mb-2">
                  <div>
                    <h4 class="text-sm font-bold text-gray-900">${job.title}</h4>
                    <p class="text-xs text-purple-600 font-semibold">${job.company} &bull; <span class="text-gray-500">${job.location} (${job.remote_status})</span></p>
                  </div>
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700">${job.opportunity_type}</span>
                </div>
                <p class="text-xs text-gray-600 mb-3 line-clamp-2">${job.description}</p>
                <div class="flex flex-wrap gap-1.5 mb-3">
                  ${job.required_skills.map(s => `
                    <span class="px-2 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-700 border border-gray-200">${s}</span>
                  `).join('')}
                </div>
                <div class="text-[11px] font-semibold text-gray-500">Stipend: ${job.stipend_salary}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // 7. AI SKILL-GAP ANALYZER VIEW
  renderGap() {
    const gap = window.elevoraStore ? window.elevoraStore.calculateSkillGap() : {
      match_percentage: 60,
      essential_matched: [{ name: "HTML5" }, { name: "CSS3" }],
      essential_missing: [{ name: "JavaScript", priority: "High" }, { name: "Git & GitHub", priority: "High" }],
      preferred_missing: [{ name: "React", priority: "Medium" }]
    };

    return `
      <div class="max-w-5xl mx-auto space-y-6">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 3</span>
          <h2 class="text-2xl font-extrabold text-[#101426]">AI Skill-Gap Analyzer</h2>
          <p class="text-xs text-gray-500 mt-1">Comparing your verified skills with current market standards for <strong>Frontend Developer</strong>.</p>
        </div>

        <!-- Transparent Math Formula Explanation -->
        <div class="p-4 rounded-xl bg-purple-50/70 border border-purple-200 text-xs text-purple-950">
          <div class="font-bold flex items-center gap-1.5 mb-1">
            <i data-lucide="calculator" class="w-4 h-4 text-purple-700"></i>
            Transparent Scoring Formula
          </div>
          <p class="text-[11px] text-gray-700">
            <strong>Skill Match Score = (Matched Essential / 5 &times; 70%) + (Matched Preferred / 2 &times; 30%) = ${gap.match_percentage}%</strong>.
            Readiness additionally weights practical project deliverables by 50%.
          </p>
        </div>

        <!-- 3 Columns: Possessed, In-Progress, Missing -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <!-- Skills Possessed -->
          <div class="elevora-card p-5 border-t-4 border-t-emerald-500">
            <h4 class="text-xs font-bold text-emerald-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <i data-lucide="check-circle" class="w-4 h-4 text-emerald-500"></i>
              Skills Possessed (${gap.essential_matched.length})
            </h4>
            <div class="space-y-2">
              ${gap.essential_matched.map(s => `
                <div class="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-100 flex items-center justify-between">
                  <span class="text-xs font-bold text-emerald-950">${s.name}</span>
                  <span class="text-[10px] text-emerald-700 font-semibold uppercase">Verified</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Essential Gaps -->
          <div class="elevora-card p-5 border-t-4 border-t-rose-500">
            <h4 class="text-xs font-bold text-rose-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <i data-lucide="alert-circle" class="w-4 h-4 text-rose-500"></i>
              Critical Missing Gaps (${gap.essential_missing.length})
            </h4>
            <div class="space-y-2">
              ${gap.essential_missing.map(m => `
                <div class="p-2.5 rounded-lg bg-rose-50/60 border border-rose-100">
                  <div class="flex items-center justify-between mb-1">
                    <span class="text-xs font-bold text-rose-950">${m.name}</span>
                    <span class="text-[10px] font-bold text-rose-600 bg-rose-100 px-1.5 py-0.5 rounded">High Priority</span>
                  </div>
                  <p class="text-[10px] text-rose-800">Directly impacts 90%+ of frontend opportunities.</p>
                  <button onclick="app.navigate('roadmap')" class="mt-2 text-[10px] font-bold text-purple-700 hover:underline">
                    Bridge in Roadmap &rarr;
                  </button>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Preferred Gaps -->
          <div class="elevora-card p-5 border-t-4 border-t-purple-400">
            <h4 class="text-xs font-bold text-purple-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <i data-lucide="star" class="w-4 h-4 text-purple-500"></i>
              Competitive Gaps (${gap.preferred_missing.length})
            </h4>
            <div class="space-y-2">
              ${gap.preferred_missing.map(m => `
                <div class="p-2.5 rounded-lg bg-purple-50/60 border border-purple-100">
                  <div class="flex items-center justify-between mb-1">
                    <span class="text-xs font-bold text-purple-950">${m.name}</span>
                    <span class="text-[10px] font-semibold text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded">Medium</span>
                  </div>
                  <p class="text-[10px] text-gray-600">Unlocks senior entry salary tiers.</p>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // 8. PERSONALIZED LEARNING ROADMAP VIEW
  renderRoadmap() {
    const store = window.elevoraStore;
    const stages = store ? store.state.roadmap_stages : [];
    const progress = store ? store.state.roadmap_progress : {};

    return `
      <div class="max-w-5xl mx-auto space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 4</span>
            <h2 class="text-2xl font-extrabold text-[#101426]">Personalized Learning Roadmap</h2>
            <p class="text-xs text-gray-500 mt-1">Free, high-quality genuine documentation curated to bridge your exact skill gaps.</p>
          </div>
          <div class="text-right">
            <span class="text-xs text-gray-500">Overall Progress</span>
            <div class="text-xl font-bold text-purple-600">${this.readiness?.roadmap_progress_percentage || 25}% Completed</div>
          </div>
        </div>

        <!-- Stages List -->
        <div class="space-y-6">
          ${stages.map(stage => `
            <div class="elevora-card p-6">
              <h3 class="text-base font-bold text-[#101426] mb-4 flex items-center gap-2">
                <span class="w-6 h-6 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-xs font-bold">
                  ${stage.stage_id}
                </span>
                <span>${stage.stage_title}</span>
              </h3>

              <div class="space-y-3">
                ${stage.lessons.map(lesson => {
                  const isDone = !!progress[lesson.lesson_id];
                  return `
                    <div class="p-4 rounded-xl border ${isDone ? 'border-emerald-200 bg-emerald-50/30' : 'border-gray-200 bg-white'} transition flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div class="flex items-start gap-3">
                        <input type="checkbox" ${isDone ? 'checked' : ''} onchange="app.toggleRoadmapLesson('${lesson.lesson_id}', this.checked)" class="w-4 h-4 mt-1 text-purple-600 rounded cursor-pointer">
                        <div>
                          <div class="flex items-center gap-2">
                            <h4 class="text-xs sm:text-sm font-bold ${isDone ? 'text-gray-500 line-through' : 'text-gray-900'}">${lesson.title}</h4>
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${isDone ? 'bg-emerald-100 text-emerald-700' : 'bg-purple-100 text-purple-700'}">${lesson.skill_name}</span>
                          </div>
                          <p class="text-xs text-gray-600 mt-1">${lesson.description}</p>
                          <div class="mt-2 flex flex-wrap items-center gap-3 text-[11px]">
                            <span class="text-gray-400">Est. Time: ${lesson.estimated_hours} hrs</span>
                            <span class="text-gray-300">&bull;</span>
                            <span class="text-purple-600 font-semibold">Resources:</span>
                            ${lesson.resources.map(r => `
                              <a href="${r.url}" target="_blank" rel="noopener noreferrer" class="text-purple-600 underline hover:text-purple-800 flex items-center gap-1">
                                <span>${r.title}</span>
                                <i data-lucide="external-link" class="w-3 h-3"></i>
                              </a>
                            `).join('')}
                          </div>
                        </div>
                      </div>

                      <button onclick="app.toggleRoadmapLesson('${lesson.lesson_id}', ${!isDone})" class="px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition ${isDone ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'gradient-primary text-white hover:opacity-95'}">
                        ${isDone ? 'Mark Incomplete' : 'Mark Complete'}
                      </button>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // 9. PRACTICAL PROJECT & SKILL EVALUATOR VIEW (THE X-FACTOR)
  renderProject() {
    const proj = this.project || (window.elevoraStore ? window.elevoraStore.state.project : {});
    const sub = this.currentSubmission;

    return `
      <div class="max-w-5xl mx-auto space-y-6">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 5 &bull; The Elevora X-Factor</span>
          <h2 class="text-2xl font-extrabold text-[#101426]">Practical Project & Skill Evaluator</h2>
          <p class="text-xs text-gray-500 mt-1">Prove your abilities by submitting practical deliverables evaluated against transparent 6-criteria rubrics.</p>
        </div>

        <!-- Project Overview Card -->
        <div class="elevora-card p-6">
          <div class="flex items-start justify-between gap-4 mb-3">
            <div>
              <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700 uppercase tracking-wider">Capstone Assignment</span>
              <h3 class="text-xl font-bold text-[#101426] mt-1">${proj.title}</h3>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-bold ${sub ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
              ${sub ? 'Submitted & Evaluated' : 'Ready for Submission'}
            </span>
          </div>
          <p class="text-xs sm:text-sm text-gray-600 leading-relaxed mb-4">${proj.overview}</p>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-gray-100 text-xs">
            <div>
              <h4 class="font-bold text-gray-900 mb-2">Learning Objectives:</h4>
              <ul class="space-y-1.5 text-gray-600">
                ${(proj.objectives || []).map(o => `
                  <li class="flex items-start gap-1.5">
                    <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0"></i>
                    <span>${o}</span>
                  </li>
                `).join('')}
              </ul>
            </div>
            <div>
              <h4 class="font-bold text-gray-900 mb-2">Required Technologies:</h4>
              <div class="flex flex-wrap gap-1.5">
                ${(proj.required_tech || []).map(t => `
                  <span class="px-2 py-1 rounded bg-purple-50 text-purple-700 border border-purple-200 font-semibold text-[11px]">${t}</span>
                `).join('')}
              </div>
            </div>
          </div>
        </div>

        <!-- 6-Criteria Rubric Breakdown -->
        <div class="elevora-card p-6">
          <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Transparent 6-Criteria Evaluation Rubric</h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            ${(proj.rubric || []).map(r => `
              <div class="p-3 rounded-xl border border-gray-200 bg-gray-50/50">
                <div class="flex items-center justify-between mb-1">
                  <span class="text-xs font-bold text-gray-900">${r.criterion}</span>
                  <span class="text-[10px] font-bold text-purple-600">${r.weight} pts</span>
                </div>
                <p class="text-[11px] text-gray-500">${r.desc}</p>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Submission Form or Evaluated Feedback -->
        ${!sub ? `
          <div class="elevora-card p-6 border-2 border-purple-200 shadow-lg">
            <div class="flex items-center justify-between mb-4">
              <div>
                <h3 class="text-base font-bold text-[#101426]">Submit Your Capstone Deliverables</h3>
                <p class="text-xs text-gray-500">Submit your live URL and GitHub repository for automated rubric grading.</p>
              </div>
              <button onclick="app.fillSampleSubmission()" class="px-3 py-1.5 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 text-xs font-semibold transition">
                ⚡ Auto-Fill Alex's Project
              </button>
            </div>

            <form onsubmit="app.handleProjectSubmit(event)" class="space-y-4">
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label class="block text-xs font-semibold text-gray-700 mb-1">Live Demo URL</label>
                  <input type="url" id="proj-live-url" required placeholder="https://yourname-taskflow.vercel.app" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300">
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-700 mb-1">GitHub Repository URL</label>
                  <input type="url" id="proj-github-url" required placeholder="https://github.com/yourname/task-manager" class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Project Description & Core Features</label>
                <textarea id="proj-desc" rows="3" required placeholder="Describe how your project satisfies the requirements (HTML semantics, responsive CSS layout, JavaScript state handling, local storage persistence)..." class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300"></textarea>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-700 mb-1">Architecture & Implementation Notes</label>
                <textarea id="proj-arch" rows="2" placeholder="Mention design patterns, state management approach, DOM event delegation, etc." class="w-full px-3 py-2 text-xs rounded-lg border border-gray-300"></textarea>
              </div>

              <button type="submit" id="proj-submit-btn" class="w-full gradient-primary text-white py-3 rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition flex items-center justify-center gap-2">
                <i data-lucide="award" class="w-4 h-4"></i>
                Submit for Rubric Evaluation & Skill Verification
              </button>
            </form>
          </div>
        ` : `
          <!-- Evaluated Results Card -->
          <div class="elevora-card p-6 border-2 border-emerald-300 bg-emerald-50/20 shadow-xl">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
              <div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wider">Evaluation Complete</span>
                <h3 class="text-xl font-bold text-gray-900 mt-1">${sub.submission_title}</h3>
                <div class="flex items-center gap-3 mt-1 text-xs text-gray-600">
                  <a href="${sub.live_url}" target="_blank" class="text-purple-600 underline font-semibold flex items-center gap-1">Live Demo <i data-lucide="external-link" class="w-3 h-3"></i></a>
                  <span>&bull;</span>
                  <a href="${sub.github_url}" target="_blank" class="text-purple-600 underline font-semibold flex items-center gap-1">GitHub Repo <i data-lucide="external-link" class="w-3 h-3"></i></a>
                </div>
              </div>
              <div class="text-right">
                <div class="text-3xl font-extrabold text-emerald-700">${sub.percentage}%</div>
                <span class="text-xs font-bold text-gray-700">${sub.grade}</span>
              </div>
            </div>

            <!-- Rubric Scores Grid -->
            <div class="mt-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center">
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">HTML Semantics</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_html || 9}/10</span>
              </div>
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">CSS Responsive</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_css || 9}/10</span>
              </div>
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">JavaScript State</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_js || 9}/10</span>
              </div>
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">Interaction UX</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_ux || 9}/10</span>
              </div>
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">Code Quality</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_code_org || 9}/10</span>
              </div>
              <div class="p-2 rounded-lg bg-white border border-gray-200">
                <span class="block text-[10px] text-gray-500">Deliverables</span>
                <span class="font-extrabold text-xs text-purple-700">${sub.scores?.score_completeness || 10}/10</span>
              </div>
            </div>

            <!-- Strengths & Improvements -->
            <div class="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div class="p-4 rounded-xl bg-white border border-gray-200">
                <h4 class="font-bold text-emerald-800 mb-2 flex items-center gap-1.5">
                  <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600"></i>
                  Demonstrated Strengths
                </h4>
                <ul class="space-y-1.5 text-gray-700">
                  ${(sub.feedback_strengths || []).map(s => `<li>&bull; ${s}</li>`).join('')}
                </ul>
              </div>
              <div class="p-4 rounded-xl bg-white border border-gray-200">
                <h4 class="font-bold text-amber-800 mb-2 flex items-center gap-1.5">
                  <i data-lucide="trending-up" class="w-4 h-4 text-amber-600"></i>
                  Areas for Polish
                </h4>
                <ul class="space-y-1.5 text-gray-700">
                  ${(sub.feedback_improvements || []).map(i => `<li>&bull; ${i}</li>`).join('')}
                </ul>
              </div>
            </div>

            <!-- Skill Upgrade Notification -->
            <div class="mt-4 p-3 rounded-xl bg-emerald-100/70 border border-emerald-300 flex items-center justify-between text-xs text-emerald-950">
              <span class="font-bold">Skills automatically upgraded to Demonstrated: JavaScript, Responsive Design, Git & GitHub!</span>
              <button onclick="app.navigate('opportunities')" class="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold hover:bg-emerald-800 transition">
                View Unlocked Jobs &rarr;
              </button>
            </div>
          </div>
        `}
      </div>
    `;
  }

  // 10. PORTFOLIO & DEMONSTRATED SKILL PROFILE VIEW
  renderPortfolio() {
    const sub = this.currentSubmission;

    return `
      <div class="max-w-5xl mx-auto space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 6</span>
            <h2 class="text-2xl font-extrabold text-[#101426]">Portfolio & Verified Skill Profile</h2>
            <p class="text-xs text-gray-500 mt-1">Honest 3-tier skill categorization showing proof of ability.</p>
          </div>
          <button onclick="app.openShareModal()" class="px-4 py-2 rounded-xl text-xs font-bold gradient-primary text-white shadow-md hover:opacity-95 transition flex items-center gap-1.5">
            <i data-lucide="share-2" class="w-3.5 h-3.5"></i>
            Share Public Profile Link
          </button>
        </div>

        <!-- Student Profile Header Card -->
        <div class="elevora-card p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div class="flex items-center gap-4">
            <div class="w-16 h-16 rounded-2xl gradient-primary text-white flex items-center justify-center font-extrabold text-2xl shadow-lg">
              ${(this.user?.full_name || 'A').charAt(0)}
            </div>
            <div>
              <h3 class="text-xl font-bold text-[#101426]">${this.user?.full_name || 'Alex Chen'}</h3>
              <p class="text-xs text-purple-600 font-semibold">${this.user?.target_career || 'Frontend Developer'} Candidate</p>
              <p class="text-[11px] text-gray-500 mt-0.5">${this.user?.education_level || 'B.Sc. CSE'} &bull; ${this.user?.academic_status || 'Undergraduate'}</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="px-3 py-1.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
              Verified Candidate Status
            </span>
          </div>
        </div>

        <!-- 3 Tiers of Skills Breakdown -->
        <div class="elevora-card p-6">
          <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4">Skill Hierarchy (Transparent 3 Tiers)</h3>
          
          <div class="space-y-6">
            <!-- Tier 2 & 3: Demonstrated & Platform-Verified -->
            <div>
              <div class="flex items-center gap-2 mb-2">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <h4 class="text-xs font-bold text-gray-900 uppercase tracking-wider">Tier 1: Demonstrated Through Capstone Deliverables</h4>
              </div>
              <div class="flex flex-wrap gap-2">
                ${this.skills.filter(s => s.status === 'demonstrated' || s.status === 'verified').map(s => `
                  <span class="px-3 py-1.5 rounded-lg text-xs font-semibold badge-demonstrated flex items-center gap-1.5">
                    <i data-lucide="shield-check" class="w-3.5 h-3.5 text-emerald-600"></i>
                    ${s.skill_name}
                  </span>
                `).join('')}
              </div>
            </div>

            <!-- Tier 1: In Progress / Learning -->
            <div>
              <div class="flex items-center gap-2 mb-2">
                <span class="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                <h4 class="text-xs font-bold text-gray-900 uppercase tracking-wider">Tier 2: Active Learning & Practice In Progress</h4>
              </div>
              <div class="flex flex-wrap gap-2">
                ${this.skills.filter(s => s.status === 'in_progress').map(s => `
                  <span class="px-3 py-1.5 rounded-lg text-xs font-semibold badge-in-progress flex items-center gap-1.5">
                    <i data-lucide="clock" class="w-3.5 h-3.5 text-purple-600"></i>
                    ${s.skill_name}
                  </span>
                `).join('')}
              </div>
            </div>
          </div>
        </div>

        <!-- Demonstrated Capstone Project Card -->
        <div class="elevora-card p-6">
          <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4">Completed Capstone Deliverables</h3>
          ${sub ? `
            <div class="p-5 rounded-xl border border-gray-200 bg-gray-50/50">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <h4 class="text-base font-bold text-[#101426]">${sub.submission_title}</h4>
                <span class="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 text-emerald-800">
                  Rubric Score: ${sub.total_score}/60 (${sub.percentage}%)
                </span>
              </div>
              <p class="text-xs text-gray-600 mb-3">${sub.description}</p>
              <div class="flex items-center gap-4 text-xs">
                <a href="${sub.live_url}" target="_blank" class="text-purple-600 font-semibold underline flex items-center gap-1">Live Application <i data-lucide="external-link" class="w-3 h-3"></i></a>
                <a href="${sub.github_url}" target="_blank" class="text-purple-600 font-semibold underline flex items-center gap-1">Source Code <i data-lucide="external-link" class="w-3 h-3"></i></a>
              </div>
            </div>
          ` : `
            <p class="text-xs text-gray-500">No project submitted yet. Visit the <button onclick="app.navigate('project')" class="text-purple-600 font-bold underline">Capstone Evaluator</button> to submit.</p>
          `}
        </div>
      </div>
    `;
  }

  // 11. OPPORTUNITY MATCHING DASHBOARD VIEW
  renderOpportunities() {
    const opps = window.elevoraStore ? window.elevoraStore.calculateOpportunities() : [];

    return `
      <div class="max-w-6xl mx-auto space-y-6">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Module 7 &bull; The Earn Phase</span>
          <h2 class="text-2xl font-extrabold text-[#101426]">Opportunity Matching Dashboard</h2>
          <p class="text-xs text-gray-500 mt-1">Match scores dynamically reflect your proven capstone achievements.</p>
        </div>

        <!-- Sample Disclaimer -->
        <div class="p-3.5 rounded-xl bg-purple-50 border border-purple-200 text-xs text-purple-900 flex items-center gap-2">
          <i data-lucide="info" class="w-4 h-4 text-purple-700 shrink-0"></i>
          <span>Educational prototype: Vacancies below are benchmark listings curated for the hackathon demonstration.</span>
        </div>

        <!-- Opportunities Grid -->
        <div class="space-y-4">
          ${opps.map(job => {
            const isApplied = !!job.application_status;
            return `
              <div class="elevora-card p-6 transition">
                <div class="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div>
                    <div class="flex items-center gap-2 mb-1">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700 uppercase tracking-wider">${job.opportunity_type}</span>
                      <span class="text-xs text-gray-400">&bull;</span>
                      <span class="text-xs text-gray-500">${job.location} (${job.remote_status})</span>
                    </div>
                    <h3 class="text-lg font-bold text-[#101426]">${job.title}</h3>
                    <p class="text-xs font-semibold text-purple-700 mb-2">${job.company} &bull; <span class="text-gray-500 font-normal">Stipend: ${job.stipend_salary}</span></p>
                    <p class="text-xs text-gray-600 max-w-2xl leading-relaxed mb-3">${job.description}</p>

                    <!-- Explanation of Match -->
                    <div class="p-3 rounded-lg ${job.is_ready_to_apply ? 'bg-emerald-50 text-emerald-950 border border-emerald-200' : 'bg-gray-50 text-gray-700 border border-gray-200'} text-xs mb-3">
                      <strong>Match Insight:</strong> ${job.explanation}
                    </div>

                    <!-- Skills Matrix -->
                    <div class="flex flex-wrap items-center gap-1.5">
                      <span class="text-[11px] font-bold text-gray-500 mr-1">Required:</span>
                      ${job.required_skills.map(s => {
                        const hasSkill = job.matched_skills.includes(s);
                        return `
                          <span class="px-2 py-0.5 rounded text-[10px] font-medium ${hasSkill ? 'badge-demonstrated' : 'badge-missing'}">
                            ${s}
                          </span>
                        `;
                      }).join('')}
                    </div>
                  </div>

                  <!-- Right: Match Score Gauge & Apply Action -->
                  <div class="flex md:flex-col items-center md:items-end justify-between md:justify-center gap-3 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-gray-100">
                    <div class="text-right">
                      <div class="text-2xl font-extrabold ${job.match_percentage >= 75 ? 'text-emerald-600' : 'text-purple-600'}">
                        ${job.match_percentage}%
                      </div>
                      <span class="text-[10px] font-semibold text-gray-500 uppercase">Match Score</span>
                    </div>

                    ${isApplied ? `
                      <span class="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1.5">
                        <i data-lucide="check" class="w-3.5 h-3.5"></i> Applied
                      </span>
                    ` : `
                      <button onclick="app.openApplyModal(${job.id}, '${job.title}', '${job.company}')" class="px-5 py-2.5 rounded-xl text-xs font-bold transition shadow-sm ${job.is_ready_to_apply ? 'gradient-primary text-white hover:opacity-95 shadow-purple-500/20' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}">
                        ${job.is_ready_to_apply ? 'Apply Now' : 'Apply Anyway'}
                      </button>
                    `}
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // =========================================================================
  // ACTIONS & HANDLERS
  // =========================================================================

  async demoLogin() {
    if (this.isApiOnline) {
      try {
        const res = await fetch(`${this.apiBase}/api/auth/demo`, { method: "POST" });
        if (res.ok) {
          const data = await res.json();
          this.user = data.user;
          this.showToast("Signed in as Demo Student: Alex Chen");
          await this.loadInitialData();
          this.navigate("dashboard");
          return;
        }
      } catch (e) {
        console.warn("API demo login failed, using local:", e);
      }
    }

    // Local fallback
    this.user = window.elevoraStore.state.user;
    this.showToast("Signed in as Demo Student: Alex Chen (Local Mode)");
    this.navigate("dashboard");
  }

  async handleAuthSubmit(event, isRegister) {
    event.preventDefault();
    const email = document.getElementById("auth-email").value;
    const password = document.getElementById("auth-password").value;
    const name = isRegister ? document.getElementById("auth-name").value : "";

    if (this.isApiOnline) {
      const endpoint = isRegister ? "/api/auth/register" : "/api/auth/login";
      try {
        const res = await fetch(`${this.apiBase}${endpoint}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password, full_name: name })
        });
        const data = await res.json();
        if (data.success) {
          this.user = data.user;
          this.showToast(isRegister ? "Account created successfully!" : "Signed in successfully!");
          await this.loadInitialData();
          this.navigate(isRegister ? "onboarding" : "dashboard");
          return;
        } else {
          this.showToast(data.error || "Authentication failed", "danger");
          return;
        }
      } catch (e) {
        console.warn("API auth error, using local fallback");
      }
    }

    // Local fallback
    this.user = { ...window.elevoraStore.state.user, email, full_name: name || "Student" };
    this.showToast("Signed in successfully (Local Engine)");
    this.navigate(isRegister ? "onboarding" : "dashboard");
  }

  async handleOnboardingSubmit(event) {
    event.preventDefault();
    const career = document.getElementById("onb-career").value;
    const edu = document.getElementById("onb-edu").value;
    const status = document.getElementById("onb-status").value;
    const hours = parseInt(document.getElementById("onb-hours").value, 10);
    const style = document.getElementById("onb-style").value;

    const selectedSkills = Array.from(document.querySelectorAll("input[name='skills']:checked")).map(cb => ({
      skill_name: cb.value,
      level: "intermediate",
      status: "demonstrated",
      source: "onboarding"
    }));

    if (this.isApiOnline) {
      try {
        await fetch(`${this.apiBase}/api/profile`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            target_career: career,
            education_level: edu,
            academic_status: status,
            weekly_hours: hours,
            skills: selectedSkills
          })
        });
        await this.loadInitialData();
        this.showToast("Profile calibrated successfully!");
        this.navigate("dashboard");
        return;
      } catch (e) {
        console.warn("API onboarding save error");
      }
    }

    // Local store
    window.elevoraStore.state.user.target_career = career;
    window.elevoraStore.state.user.education_level = edu;
    window.elevoraStore.state.user.academic_status = status;
    window.elevoraStore.state.user.weekly_hours = hours;
    window.elevoraStore.state.skills = selectedSkills;
    window.elevoraStore.saveState();

    this.showToast("Profile calibrated successfully! (Local Mode)");
    await this.loadInitialData();
    this.navigate("dashboard");
  }

  async toggleRoadmapLesson(lessonId, isCompleted) {
    if (this.isApiOnline) {
      try {
        await fetch(`${this.apiBase}/api/roadmap/toggle-lesson`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ lesson_id: lessonId, is_completed: isCompleted })
        });
      } catch (e) {
        console.warn("API toggle error");
      }
    }

    // Update local store
    window.elevoraStore.toggleLesson(lessonId, isCompleted);
    await this.loadInitialData();
    this.navigate(this.activeRoute, false);
    this.showToast(isCompleted ? "Lesson marked complete!" : "Lesson marked incomplete", "info");
  }

  fillSampleSubmission() {
    const live = document.getElementById("proj-live-url");
    const gh = document.getElementById("proj-github-url");
    const desc = document.getElementById("proj-desc");
    const arch = document.getElementById("proj-arch");

    if (live) live.value = "https://alexchen-taskflow.vercel.app";
    if (gh) gh.value = "https://github.com/alexchen/taskflow-pro";
    if (desc) desc.value = "An interactive, responsive Task Management application built with clean semantic HTML5 header/main/section elements, modern CSS Grid/Flexbox layouts, and modular vanilla JavaScript. Features dynamic task creation, status filtering (All, In Progress, Completed), and client-side persistence.";
    if (arch) arch.value = "Used state-driven architecture pattern with dynamic DOM event delegation and persistent Web Storage API (localStorage). Structured CSS tokens for mobile and desktop viewports.";
    this.showToast("Alex Chen's sample deliverables populated!");
  }

  async handleProjectSubmit(event) {
    event.preventDefault();
    const live = document.getElementById("proj-live-url").value;
    const gh = document.getElementById("proj-github-url").value;
    const desc = document.getElementById("proj-desc").value;
    const arch = document.getElementById("proj-arch").value;

    const submitBtn = document.getElementById("proj-submit-btn");
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="animate-spin inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></span> Evaluating with Rubrics...`;
    }

    let evaluation = null;

    if (this.isApiOnline) {
      try {
        const res = await fetch(`${this.apiBase}/api/projects/submit`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            submission_title: "Interactive Task Management Web Application",
            live_url: live,
            github_url: gh,
            description: desc,
            architecture_notes: arch
          })
        });
        const data = await res.json();
        if (data.success) {
          evaluation = data.evaluation;
        }
      } catch (e) {
        console.warn("API project submission failed, falling back to local:", e);
      }
    }

    if (!evaluation) {
      evaluation = window.elevoraStore.submitProject({
        submission_title: "Interactive Task Management Web Application",
        live_url: live,
        github_url: gh,
        description: desc,
        architecture_notes: arch
      });
    }

    // Trigger celebration confetti
    if (window.confetti) {
      confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
    }

    this.showToast(`Evaluation Complete! Grade: ${evaluation.grade} (${evaluation.percentage}%)`);
    await this.loadInitialData();
    this.navigate("project", false);
  }

  async sendAdvisorQuery(query) {
    const input = document.getElementById("advisor-input");
    if (input) input.value = query;
    this.handleAdvisorSubmit(new Event("submit"));
  }

  async handleAdvisorSubmit(event) {
    if (event) event.preventDefault();
    const input = document.getElementById("advisor-input");
    if (!input || !input.value.trim()) return;

    const query = input.value.trim();
    input.value = "";

    const msgContainer = document.getElementById("advisor-messages");
    if (msgContainer) {
      // Append user message
      const userDiv = document.createElement("div");
      userDiv.className = "flex items-start justify-end gap-3";
      userDiv.innerHTML = `
        <div class="p-3.5 rounded-2xl bg-purple-600 text-white text-xs sm:text-sm max-w-xl leading-relaxed">
          ${query}
        </div>
      `;
      msgContainer.appendChild(userDiv);

      // Append loading indicator
      const loaderDiv = document.createElement("div");
      loaderDiv.id = "advisor-loading";
      loaderDiv.className = "flex items-start gap-3";
      loaderDiv.innerHTML = `
        <div class="w-8 h-8 rounded-lg gradient-primary text-white flex items-center justify-center shrink-0">
          <i data-lucide="bot" class="w-4 h-4"></i>
        </div>
        <div class="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 text-xs text-gray-500">
          <span class="animate-pulse">Analyzing profile & generating structured guidance...</span>
        </div>
      `;
      msgContainer.appendChild(loaderDiv);
      msgContainer.scrollTop = msgContainer.scrollHeight;
    }

    let responseData = null;

    if (this.isApiOnline) {
      try {
        const res = await fetch(`${this.apiBase}/api/advisor/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query })
        });
        if (res.ok) {
          const data = await res.json();
          responseData = data.response;
        }
      } catch (e) {
        console.warn("Advisor API error");
      }
    }

    if (!responseData) {
      // High-quality local fallback response
      responseData = {
        source: "Elevora Heuristic Career Advisor",
        message: `### Guidance for ${this.user?.full_name || 'Alex'}\n**Target:** Frontend Developer\n\n1. **Market Expectations:** In 2026, recruiters prioritize candidates who build interactive stateful apps over static brochure sites.\n2. **Your Current Strengths:** Strong fundamentals in semantic HTML5 & responsive CSS Flexbox/Grid.\n3. **Critical Gap:** Demonstrating JavaScript state handling and Web Storage APIs.\n4. **Recommended Pathway:** Complete the Capstone Project (Interactive Task Manager), submit for rubric grading, and unlock entry-level internships!`
      };
    }

    const loader = document.getElementById("advisor-loading");
    if (loader) loader.remove();

    if (msgContainer) {
      const botDiv = document.createElement("div");
      botDiv.className = "flex items-start gap-3";
      const formattedMessage = (responseData.message || '').replace(/\n/g, '<br>').replace(/### (.*?)(<br>|$)/g, '<h4 class="font-bold text-gray-900 text-sm mt-2 mb-1">$1</h4>');

      botDiv.innerHTML = `
        <div class="w-8 h-8 rounded-lg gradient-primary text-white flex items-center justify-center shrink-0">
          <i data-lucide="bot" class="w-4 h-4"></i>
        </div>
        <div class="p-4 rounded-2xl bg-gray-50 border border-gray-200 text-xs sm:text-sm text-gray-800 max-w-2xl leading-relaxed">
          <div class="flex items-center justify-between mb-2 pb-1 border-b border-gray-200 text-[10px] text-gray-500 font-semibold">
            <span>Advisor Response</span>
            <span class="text-purple-600 font-bold">${responseData.source || 'Elevora AI'}</span>
          </div>
          <div>${formattedMessage}</div>
        </div>
      `;
      msgContainer.appendChild(botDiv);
      msgContainer.scrollTop = msgContainer.scrollHeight;
      if (window.lucide) lucide.createIcons();
    }
  }

  openApplyModal(jobId, jobTitle, company) {
    const modal = document.getElementById("modal-container");
    if (!modal) return;
    modal.classList.remove("hidden");
    modal.innerHTML = `
      <div class="fixed inset-0 bg-midnight/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div class="elevora-card max-w-md w-full p-6 shadow-2xl animate-fade-in">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-base font-bold text-gray-900">Confirm Application</h3>
            <button onclick="app.closeModal()" class="text-gray-400 hover:text-gray-600">
              <i data-lucide="x" class="w-5 h-5"></i>
            </button>
          </div>
          <p class="text-xs text-gray-600 mb-4">
            You are applying for <strong>${jobTitle}</strong> at <strong>${company}</strong>. Your Elevora verified skill badges and capstone deliverables will be transmitted with your candidate dossier.
          </p>
          <div class="p-3 rounded-xl bg-purple-50 text-xs text-purple-950 font-semibold mb-5">
            Verified Dossier: Alex Chen &bull; B.Sc. CSE &bull; Capstone Score: ${this.currentSubmission ? this.currentSubmission.percentage + '%' : 'Pending'}
          </div>
          <div class="flex justify-end gap-3">
            <button onclick="app.closeModal()" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
            <button onclick="app.submitApplication(${jobId})" class="gradient-primary text-white px-5 py-2 rounded-lg text-xs font-bold shadow-md hover:opacity-95">
              Transmit Application &rarr;
            </button>
          </div>
        </div>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
  }

  async submitApplication(jobId) {
    if (this.isApiOnline) {
      try {
        await fetch(`${this.apiBase}/api/opportunities/apply`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ job_id: jobId })
        });
      } catch (e) {
        console.warn("API application submit error");
      }
    }

    window.elevoraStore.applyJob(jobId);
    this.closeModal();
    this.showToast("Application submitted successfully! Recruiter notified.");
    await this.loadInitialData();
    this.navigate("opportunities", false);
  }

  openShareModal() {
    const modal = document.getElementById("modal-container");
    if (!modal) return;
    const shareUrl = `${window.location.origin}/#portfolio?user=alexchen`;
    modal.classList.remove("hidden");
    modal.innerHTML = `
      <div class="fixed inset-0 bg-midnight/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div class="elevora-card max-w-md w-full p-6 shadow-2xl animate-fade-in">
          <div class="flex items-center justify-between mb-3">
            <h3 class="text-base font-bold text-gray-900">Share Public Verified Profile</h3>
            <button onclick="app.closeModal()" class="text-gray-400 hover:text-gray-600">
              <i data-lucide="x" class="w-5 h-5"></i>
            </button>
          </div>
          <p class="text-xs text-gray-600 mb-4">Anyone with this link can view your verified skills, project rubric scores, and live demo links.</p>
          <div class="flex items-center gap-2 p-2 rounded-lg border border-gray-300 bg-gray-50 mb-5">
            <input type="text" readonly value="${shareUrl}" id="share-url-input" class="flex-1 bg-transparent text-xs text-gray-700 outline-none">
            <button onclick="navigator.clipboard.writeText('${shareUrl}'); app.showToast('Link copied to clipboard!');" class="px-3 py-1.5 rounded bg-purple-600 text-white font-bold text-xs hover:bg-purple-700">Copy</button>
          </div>
          <button onclick="app.closeModal()" class="w-full bg-[#101426] text-white py-2 rounded-lg text-xs font-semibold">Done</button>
        </div>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
  }

  closeModal() {
    const modal = document.getElementById("modal-container");
    if (modal) modal.classList.add("hidden");
  }

  async resetDemoData() {
    if (this.isApiOnline) {
      try {
        await fetch(`${this.apiBase}/api/reset-demo`, { method: "POST" });
      } catch (e) {
        console.warn("API demo reset failed");
      }
    }

    window.elevoraStore.resetState();
    await this.loadInitialData();
    this.showToast("Demo state reset to Step 1 initial state!", "info");
    this.navigate("dashboard");
  }

  switchPersonaModal() {
    this.showToast("Alex Chen (CSE 3rd Year targeting Frontend Developer) active.");
  }

  // =========================================================================
  // 9-STEP HACKATHON DEMO WALKTHROUGH CONTROLLER
  // =========================================================================
  async runJudgeStep(step) {
    this.currentJudgeStep = step;

    switch (step) {
      case 1:
        // Step 1: Profile & Target Role
        this.navigate("dashboard");
        this.showToast("Step 1: Alex Chen's profile loaded — Target: Frontend Developer.");
        break;
      case 2:
        // Step 2: Market Job Analytics
        this.navigate("market");
        this.showToast("Step 2: Analyzed 5 benchmark job listings for Frontend Developer.");
        break;
      case 3:
        // Step 3: Skill Gaps
        this.navigate("gap");
        this.showToast("Step 3: Identified JavaScript & Git as critical missing skill gaps.");
        break;
      case 4:
        // Step 4: Learning Roadmap
        this.navigate("roadmap");
        this.showToast("Step 4: Personalized 5-stage roadmap generated with genuine docs.");
        break;
      case 5:
        // Step 5: Practical Capstone Assignment
        this.navigate("project");
        this.showToast("Step 5: Assigned Capstone: Interactive Task Management Web App.");
        break;
      case 6:
        // Step 6: Submit & Evaluate Project
        this.navigate("project");
        if (!this.currentSubmission) {
          this.fillSampleSubmission();
          const form = document.querySelector("form");
          if (form) this.handleProjectSubmit(new Event("submit"));
        } else {
          this.showToast("Step 6: Project evaluated! Score: 54/60 (90%) - Grade A+.");
        }
        break;
      case 7:
        // Step 7: Demonstrated Skill Profile
        this.navigate("portfolio");
        this.showToast("Step 7: Demonstrated skills upgraded automatically (JavaScript proven)!");
        break;
      case 8:
        // Step 8: Opportunity Matching
        this.navigate("opportunities");
        this.showToast("Step 8: Match score for CloudScale Intern upgraded from 52% to 92%!");
        break;
      case 9:
        // Step 9: Public Shareable Portfolio
        this.navigate("portfolio");
        this.openShareModal();
        this.showToast("Step 9: Public verified portfolio ready to share with recruiters.");
        break;
    }
  }
}

// Instantiate and start app
window.app = new ElevoraApp();
window.addEventListener("DOMContentLoaded", () => {
  window.app.init();
});
