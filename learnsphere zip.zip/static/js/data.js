/**
 * ELEVORA AI - Client Data Store & Heuristic Calculation Engine
 * Contains curated benchmark datasets and transparent calculation algorithms.
 */

const DEFAULT_STATE = {
  user: {
    id: 1,
    full_name: "Alex Chen",
    email: "demo@elevora.ai",
    education_level: "Bachelor of Science (CSE, 3rd Year)",
    academic_status: "Undergraduate Student",
    target_career: "Frontend Developer",
    experience_level: "Beginner / Intermediate",
    weekly_hours: 14,
    learning_style: "Practical Projects & Code Demos",
    onboarding_completed: true
  },
  skills: [
    { skill_name: "HTML5", level: "intermediate", status: "demonstrated", source: "onboarding" },
    { skill_name: "CSS3", level: "intermediate", status: "demonstrated", source: "onboarding" },
    { skill_name: "Responsive Design", level: "intermediate", status: "demonstrated", source: "onboarding" },
    { skill_name: "JavaScript", level: "beginner", status: "in_progress", source: "onboarding" },
    { skill_name: "Git & GitHub", level: "beginner", status: "in_progress", source: "onboarding" }
  ],
  roadmap_progress: {
    "fund-101": true,
    "fund-102": true
  },
  project_submission: null,
  applications: {},
  jobs: [
    {
      id: 1,
      slug: "cloudscale-junior-frontend-intern",
      title: "Junior Frontend Developer Intern",
      company: "CloudScale Technologies",
      opportunity_type: "Internship",
      location: "San Francisco, CA",
      remote_status: "Remote",
      experience_level: "Entry-Level / Student",
      stipend_salary: "$30 - $38 / hr",
      description: "CloudScale is seeking a passionate Frontend Intern to join our web app team. You will collaborate on building modern user interfaces, integrating RESTful APIs, and turning design prototypes into accessible web components.",
      required_skills: ["HTML5", "CSS3", "JavaScript", "Git & GitHub", "Responsive Design"],
      preferred_skills: ["React", "API Integration", "TypeScript"],
      application_url: "https://careers.cloudscale-sample.io/jobs/frontend-intern"
    },
    {
      id: 2,
      slug: "novatech-ui-engineering-fellow",
      title: "Associate UI Engineer",
      company: "NovaTech Labs",
      opportunity_type: "Entry-Level Junior",
      location: "New York, NY",
      remote_status: "Hybrid",
      experience_level: "0-1 Years Experience",
      stipend_salary: "$70,000 - $85,000 / yr",
      description: "Work directly with product designers and backend engineers to develop rich, responsive web applications. Candidates must possess demonstrated competence in JavaScript, CSS Grid/Flexbox, and component architecture.",
      required_skills: ["HTML5", "CSS3", "JavaScript", "React", "Git & GitHub"],
      preferred_skills: ["API Integration", "Tailwind CSS", "Unit Testing"],
      application_url: "https://novatech-sample.dev/careers/associate-ui"
    },
    {
      id: 3,
      slug: "apexdigital-web-developer-trainee",
      title: "Junior Web Developer",
      company: "Apex Digital Studio",
      opportunity_type: "Entry-Level Junior",
      location: "Austin, TX",
      remote_status: "Remote",
      experience_level: "Entry-Level",
      stipend_salary: "$65,000 - $78,000 / yr",
      description: "Apex Digital crafts high-performance web products for fast-growing companies. We welcome graduates with strong fundamentals in semantic HTML, modern responsive CSS, and DOM programming.",
      required_skills: ["HTML5", "CSS3", "JavaScript", "Responsive Design", "Git & GitHub"],
      preferred_skills: ["React", "Performance Optimization"],
      application_url: "https://apexdigital-sample.com/apply/jr-web"
    },
    {
      id: 4,
      slug: "finpulse-frontend-fellow",
      title: "Frontend Engineering Apprentice",
      company: "FinPulse Solutions",
      opportunity_type: "Internship",
      location: "Boston, MA",
      remote_status: "On-Site",
      experience_level: "Undergraduate / Graduate",
      stipend_salary: "$28 - $34 / hr",
      description: "Join FinPulse's 6-month apprentice program. You'll gain hands-on experience building financial analytics dashboards, working with REST APIs, and writing maintainable frontend code.",
      required_skills: ["HTML5", "CSS3", "JavaScript", "Git & GitHub"],
      preferred_skills: ["React", "API Integration", "Chart.js"],
      application_url: "https://finpulse-sample.org/fellowship"
    },
    {
      id: 5,
      slug: "eduvibe-frontend-apprentice",
      title: "Junior React & Web Developer",
      company: "EduVibe Interactive",
      opportunity_type: "Entry-Level Junior",
      location: "Seattle, WA",
      remote_status: "Remote",
      experience_level: "0-2 Years",
      stipend_salary: "$72,000 - $88,000 / yr",
      description: "EduVibe builds interactive learning tools for higher education. We value candidates who have built practical projects, demonstrated clean code organization, and understand modern state management.",
      required_skills: ["HTML5", "CSS3", "JavaScript", "React", "API Integration"],
      preferred_skills: ["Git & GitHub", "TypeScript", "Accessibility"],
      application_url: "https://eduvibe-sample.tech/jobs/react-dev"
    }
  ],
  roadmap_stages: [
    {
      stage_id: 1,
      stage_title: "Stage 1: Strengthen Fundamentals",
      lessons: [
        {
          lesson_id: "fund-101",
          skill_name: "HTML5",
          title: "Modern Semantic HTML & Accessibility (a11y)",
          description: "Master clean document outlines, ARIA attributes, semantic tags (main, nav, article), and accessible forms.",
          estimated_hours: 4,
          priority: "Essential",
          resources: [
            { title: "MDN: HTML Semantic Elements", url: "https://developer.mozilla.org/en-US/docs/Glossary/Semantics#semantics_in_html" },
            { title: "freeCodeCamp: Responsive Web Design", url: "https://www.freecodecamp.org/learn/2022/responsive-web-design/" }
          ],
          practice_activity: "Refactor a div-soup landing page into a clean, keyboard-navigable semantic document structure."
        },
        {
          lesson_id: "fund-102",
          skill_name: "CSS3",
          title: "Modern CSS Layouts: Flexbox, Grid & Responsive Tokens",
          description: "Build production layouts without frameworks using CSS Flexbox, Grid, container queries, and mobile-first media queries.",
          estimated_hours: 6,
          priority: "Essential",
          resources: [
            { title: "MDN: CSS Grid Layout Guide", url: "https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout" },
            { title: "CSS-Tricks: Complete Guide to Flexbox", url: "https://css-tricks.com/snippets/css/a-guide-to-flexbox/" }
          ],
          practice_activity: "Create a fully responsive dashboard card grid that adapts seamlessly across mobile, tablet, and widescreen viewports."
        }
      ]
    },
    {
      stage_id: 2,
      stage_title: "Stage 2: Master JavaScript",
      lessons: [
        {
          lesson_id: "js-201",
          skill_name: "JavaScript",
          title: "Modern JavaScript ES6+ & Data Structures",
          description: "Deep dive into array methods (map, filter, reduce), destructuring, closures, spread/rest syntax, and ES modules.",
          estimated_hours: 8,
          priority: "Essential",
          resources: [
            { title: "JavaScript.info: The Modern JavaScript Tutorial", url: "https://javascript.info/" },
            { title: "MDN: JavaScript Language Overview", url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript" }
          ],
          practice_activity: "Implement a client-side filter and sorting algorithm for tabular job and skill records."
        },
        {
          lesson_id: "js-202",
          skill_name: "JavaScript",
          title: "DOM Manipulation, Event Architecture & LocalStorage",
          description: "Learn event delegation, dynamic DOM rendering, custom events, and persistent browser storage APIs.",
          estimated_hours: 7,
          priority: "Essential",
          resources: [
            { title: "MDN: Introduction to the DOM", url: "https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model/Introduction" },
            { title: "MDN: Window.localStorage", url: "https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage" }
          ],
          practice_activity: "Build an interactive task list where tasks can be added, toggled, and persisted across browser reloads."
        }
      ]
    },
    {
      stage_id: 3,
      stage_title: "Stage 3: Version Control & Git",
      lessons: [
        {
          lesson_id: "git-301",
          skill_name: "Git & GitHub",
          title: "Professional Git Workflow, Branching & GitHub PRs",
          description: "Essential version control commands, atomic commits, feature branches, resolving merge conflicts, and writing clean pull request descriptions.",
          estimated_hours: 5,
          priority: "Essential",
          resources: [
            { title: "GitHub Docs: Git Cheat Sheet", url: "https://docs.github.com/en/get-started/quickstart/git-and-github-learning-resources" },
            { title: "Atlassian Git Tutorial", url: "https://www.atlassian.com/git/tutorials" }
          ],
          practice_activity: "Initialize a repository, create a feature branch, resolve a staged merge conflict, and submit a documented pull request."
        }
      ]
    },
    {
      stage_id: 4,
      stage_title: "Stage 4: Learn React",
      lessons: [
        {
          lesson_id: "react-401",
          skill_name: "React",
          title: "React Core: JSX, Components, Props & State",
          description: "Understand declarative UI programming, unidirectional data flow, component decomposition, and useState fundamentals.",
          estimated_hours: 10,
          priority: "Essential",
          resources: [
            { title: "Official React Documentation (react.dev)", url: "https://react.dev/learn" },
            { title: "freeCodeCamp: React for Beginners", url: "https://www.freecodecamp.org/news/tag/react/" }
          ],
          practice_activity: "Break down an interactive dashboard widget into isolated, reusable presentational and container components."
        },
        {
          lesson_id: "react-402",
          skill_name: "React",
          title: "Hooks Deep Dive: useEffect, Custom Hooks & Performance",
          description: "Manage component side-effects, API calls, event listeners cleanup, memoization, and extracting business logic into custom hooks.",
          estimated_hours: 8,
          priority: "Essential",
          resources: [
            { title: "React Docs: Synchronizing with Effects", url: "https://react.dev/learn/synchronizing-with-effects" },
            { title: "React Docs: Reusing Logic with Custom Hooks", url: "https://react.dev/learn/reusing-logic-with-custom-hooks" }
          ],
          practice_activity: "Construct a custom useLocalStorage hook that synchronizes component state with browser storage."
        }
      ]
    },
    {
      stage_id: 5,
      stage_title: "Stage 5: API Integration & Practical Development",
      lessons: [
        {
          lesson_id: "api-501",
          skill_name: "API Integration",
          title: "REST APIs, Fetch/Axios, Async/Await & Robust Error Handling",
          description: "Master asynchronous client-server communication, JSON parsing, HTTP headers, loading states, error boundaries, and debounce strategies.",
          estimated_hours: 7,
          priority: "Essential",
          resources: [
            { title: "MDN: Using the Fetch API", url: "https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch" },
            { title: "REST API Tutorial", url: "https://restfulapi.net/" }
          ],
          practice_activity: "Implement a live search bar that queries an external public API with debounced user input and visual fallback states."
        }
      ]
    }
  ],
  project: {
    id: 1,
    slug: "task-management-app",
    title: "Interactive Task Management Web Application",
    career_track: "Frontend Developer",
    overview: "Build an interactive, responsive task management application (Kanban / Todo style). Apply HTML5 semantic structure, modern responsive CSS layouts, modular JavaScript logic, state persistence via LocalStorage, and clean UX to prove your frontend readiness.",
    objectives: [
      "Demonstrate clean, semantic HTML5 structure and accessible form elements.",
      "Implement modern CSS Flexbox and Grid layouts responsive from mobile to desktop.",
      "Write modular JavaScript managing tasks state (create, toggle status, edit, delete).",
      "Implement task filtering by status (All, Active, Completed) and search query.",
      "Persist task data locally using Web Storage API (localStorage).",
      "Deliver clean code organization with documented Git commits."
    ],
    required_tech: ["HTML5", "CSS3 / Responsive Design", "JavaScript (ES6+)", "Git & GitHub", "Web Storage API"],
    milestones: [
      { id: "m1", title: "Milestone 1: Semantic Document Architecture & Accessibility", desc: "Setup semantic tags, accessible forms, aria-labels, and base HTML structure." },
      { id: "m2", title: "Milestone 2: Responsive Visual Styling & Layouts", desc: "Design a clean desktop & mobile UI using CSS Flexbox/Grid with modern styling." },
      { id: "m3", title: "Milestone 3: Dynamic State & DOM Manipulation", desc: "Write JS functions to render tasks, handle additions, status toggling, and deletions." },
      { id: "m4", title: "Milestone 4: Storage Persistence & Search/Filter Controls", desc: "Add LocalStorage sync and filter controls (All, In Progress, Completed)." }
    ],
    rubric: [
      { criterion: "HTML Structure & Semantic Quality", weight: 10, desc: "Proper use of header, main, section, nav, form tags, and accessible input labeling." },
      { criterion: "CSS Styling & Responsiveness", weight: 10, desc: "Fluid mobile-to-desktop layout, readable typography, contrast adherence, and clean transitions." },
      { criterion: "JavaScript Functionality & State", weight: 10, desc: "Correct state updates, immutable data patterns, event listeners, and filtering logic." },
      { criterion: "User Interaction & UX Polish", weight: 10, desc: "Clear active states, form validation, confirmation toasts, and intuitive task actions." },
      { criterion: "Code Organization & Best Practices", weight: 10, desc: "Modular functions, clean variable naming, separation of concerns, and meaningful Git commits." },
      { criterion: "Overall Completeness & Polish", weight: 10, desc: "All requirements satisfied, zero console bugs, and thoughtful attention to detail." }
    ]
  }
};

class ElevoraStore {
  constructor() {
    this.storageKey = "elevora_ai_state_v1";
    this.state = this.loadState();
  }

  loadState() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_STATE, ...parsed };
      }
    } catch (e) {
      console.warn("LocalStorage unavailable, using in-memory state:", e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  saveState() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.state));
    } catch (e) {
      console.warn("Could not save to LocalStorage:", e);
    }
  }

  resetState() {
    this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    this.saveState();
    return this.state;
  }

  // -------------------------------------------------------------
  // TRANSPARENT MATH & METRIC ENGINES
  // -------------------------------------------------------------
  calculateSkillGap() {
    const marketEssential = ["HTML5", "CSS3", "JavaScript", "Responsive Design", "Git & GitHub"];
    const marketPreferred = ["React", "API Integration", "Web Storage API"];

    const userSkillNames = new Set(this.state.skills.map(s => s.skill_name.trim().toLowerCase()));
    const demonstratedSkillNames = new Set(
      this.state.skills
        .filter(s => s.status === "demonstrated" || s.status === "verified")
        .map(s => s.skill_name.trim().toLowerCase())
    );

    const essentialMatched = [];
    const essentialMissing = [];

    for (const req of marketEssential) {
      const norm = req.toLowerCase();
      if (userSkillNames.has(norm)) {
        const isDemo = demonstratedSkillNames.has(norm);
        essentialMatched.append ? essentialMatched.push({ name: req, status: isDemo ? "demonstrated" : "in_progress" }) : essentialMatched.push({ name: req, status: isDemo ? "demonstrated" : "in_progress" });
      } else {
        essentialMissing.push({ name: req, status: "missing", priority: "High" });
      }
    }

    const preferredMatched = [];
    const preferredMissing = [];

    for (const pref of marketPreferred) {
      const norm = pref.toLowerCase();
      if (userSkillNames.has(norm)) {
        const isDemo = demonstratedSkillNames.has(norm);
        preferredMatched.push({ name: pref, status: isDemo ? "demonstrated" : "in_progress" });
      } else {
        preferredMissing.push({ name: pref, status: "missing", priority: "Medium" });
      }
    }

    const essentialScore = (essentialMatched.length / marketEssential.length) * 70.0;
    const preferredScore = (preferredMatched.length / marketPreferred.length) * 30.0;
    const rawMatchPercentage = Math.round((essentialScore + preferredScore) * 10) / 10;

    const demonstratedRatio = demonstratedSkillNames.size / marketEssential.length;
    const readinessPercentage = Math.min(100.0, Math.round(((rawMatchPercentage * 0.5) + (demonstratedRatio * 50.0)) * 10) / 10);

    return {
      match_percentage: rawMatchPercentage,
      readiness_percentage: readinessPercentage,
      essential_matched: essentialMatched,
      essential_missing: essentialMissing,
      preferred_matched: preferredMatched,
      preferred_missing: preferredMissing,
      demonstrated_count: demonstratedSkillNames.size
    };
  }

  calculateReadiness() {
    const gap = this.calculateSkillGap();
    const completedLessons = Object.values(this.state.roadmap_progress).filter(Boolean).length;
    const totalLessons = this.state.roadmap_stages.reduce((acc, s) => acc + s.lessons.length, 0);
    const roadmapPct = Math.round((completedLessons / totalLessons) * 100);
    const hasCompletedProject = this.state.project_submission && this.state.project_submission.percentage >= 70;

    let stage = "LEARN";
    if (hasCompletedProject) {
      stage = "EARN";
    } else if (roadmapPct >= 50 || gap.demonstrated_count >= 3) {
      stage = "PROVE";
    }

    return {
      overall_score: gap.readiness_percentage,
      skill_match_percentage: gap.match_percentage,
      lessons_completed: completedLessons,
      total_lessons: totalLessons,
      roadmap_progress_percentage: roadmapPct,
      projects_completed: hasCompletedProject ? 1 : 0,
      stage: stage
    };
  }

  calculateOpportunities() {
    const userSkillNames = new Set(this.state.skills.map(s => s.skill_name.toLowerCase()));
    const demonstratedNames = new Set(
      this.state.skills
        .filter(s => s.status === "demonstrated" || s.status === "verified")
        .map(s => s.skill_name.toLowerCase())
    );

    return this.state.jobs.map(job => {
      const matchedReq = job.required_skills.filter(s => userSkillNames.has(s.toLowerCase()));
      const missingReq = job.required_skills.filter(s => !userSkillNames.has(s.toLowerCase()));
      const matchedPref = job.preferred_skills.filter(s => userSkillNames.has(s.toLowerCase()));
      const missingPref = job.preferred_skills.filter(s => !userSkillNames.has(s.toLowerCase()));

      const reqScore = (matchedReq.length / Math.max(job.required_skills.length, 1)) * 75.0;
      const prefScore = (matchedPref.length / Math.max(job.preferred_skills.length, 1)) * 25.0;
      const matchPct = Math.round((reqScore + prefScore) * 10) / 10;

      const provenCount = job.required_skills.filter(s => demonstratedNames.has(s.toLowerCase())).length;
      const isReadyToApply = matchPct >= 75.0 && provenCount >= 2;

      let explanation = "";
      if (isReadyToApply) {
        explanation = `Strong match (${matchPct}%). You possess ${matchedReq.length}/${job.required_skills.length} essential skills with verified project deliverables.`;
      } else {
        const missingStr = missingReq.slice(0, 2).join(", ");
        explanation = `Moderate match (${matchPct}%). To become a competitive applicant, complete and verify: ${missingStr || 'further project work'}.`;
      }

      return {
        ...job,
        matched_skills: [...matchedReq, ...matchedPref],
        missing_skills: [...missingReq, ...missingPref],
        match_percentage: matchPct,
        is_ready_to_apply: isReadyToApply,
        explanation: explanation,
        application_status: this.state.applications[job.id] || null
      };
    }).sort((a, b) => b.match_percentage - a.match_percentage);
  }

  toggleLesson(lessonId, isCompleted) {
    this.state.roadmap_progress[lessonId] = isCompleted;

    // Advance skill to in-progress if completed
    let skillFound = null;
    for (const stage of this.state.roadmap_stages) {
      const lesson = stage.lessons.find(l => l.lesson_id === lessonId);
      if (lesson) {
        skillFound = lesson.skill_name;
        break;
      }
    }

    if (skillFound && isCompleted) {
      const existing = this.state.skills.find(s => s.skill_name.toLowerCase() === skillFound.toLowerCase());
      if (existing) {
        if (existing.status !== "demonstrated" && existing.status !== "verified") {
          existing.status = "in_progress";
        }
      } else {
        this.state.skills.push({
          skill_name: skillFound,
          level: "intermediate",
          status: "in_progress",
          source: "roadmap"
        });
      }
    }

    this.saveState();
  }

  submitProject(submissionData) {
    const title = submissionData.submission_title || "Interactive Task Management Web Application";
    const liveUrl = submissionData.live_url || "";
    const githubUrl = submissionData.github_url || "";
    const desc = submissionData.description || "";
    const arch = submissionData.architecture_notes || "";

    const combinedText = (desc + " " + arch).toLowerCase();

    const scoreHtml = (combinedText.includes("semantic") || combinedText.includes("header")) ? 9 : 8;
    const scoreCss = (combinedText.includes("responsive") || combinedText.includes("flexbox") || combinedText.includes("grid")) ? 9 : 8;
    const scoreJs = (combinedText.includes("localstorage") || combinedText.includes("state") || combinedText.includes("filter")) ? 9 : 8;
    const scoreUx = (combinedText.includes("active") || combinedText.includes("validation")) ? 9 : 8;
    const scoreCodeOrg = githubUrl.startsWith("http") ? 9 : 7;
    const scoreCompleteness = (liveUrl && githubUrl && desc.length > 30) ? 10 : 8;

    const totalScore = scoreHtml + scoreCss + scoreJs + scoreUx + scoreCodeOrg + scoreCompleteness;
    const percentage = Math.round((totalScore / 60.0) * 1000) / 10;
    const grade = percentage >= 90 ? "A+ (Workforce Ready)" : percentage >= 80 ? "A (Strong Competency)" : "B (Good Progress)";

    const strengths = [
      "Well-structured semantic HTML hierarchy with accessible interactive controls.",
      "Demonstrated responsive layout behavior using modern CSS grid and flexbox.",
      "Functional JavaScript state management with clean separation of task manipulation logic.",
      "Successful client-side data persistence utilizing browser localStorage."
    ];

    const improvements = [
      "Consider incorporating keyboard shortcuts (e.g. Enter to add, Escape to cancel editing) for enhanced a11y.",
      "Add subtle transition animations when task items are filtered or deleted to improve visual feedback.",
      "Include unit tests or JSDoc comments to document core helper functions."
    ];

    const actionItems = [
      "Mark JavaScript and Responsive Web Design as 'Demonstrated' in your Skill Profile.",
      "Add the verified project badge to your public Elevora portfolio.",
      "Proceed to explore the newly unlocked internship matches (e.g. CloudScale Technologies)!"
    ];

    const unlocked = ["JavaScript", "Responsive Design", "Git & GitHub", "Web Storage API"];

    const evaluation = {
      id: Date.now(),
      project_id: 1,
      submission_title: title,
      live_url: liveUrl,
      github_url: githubUrl,
      description: desc,
      architecture_notes: arch,
      scores: {
        score_html: scoreHtml,
        score_css: scoreCss,
        score_js: scoreJs,
        score_ux: scoreUx,
        score_code_org: scoreCodeOrg,
        score_completeness: scoreCompleteness
      },
      total_score: totalScore,
      max_score: 60,
      percentage: percentage,
      grade: grade,
      feedback_strengths: strengths,
      feedback_improvements: improvements,
      feedback_action_items: actionItems,
      demonstrated_skills_unlocked: unlocked,
      submitted_at: new Date().toISOString()
    };

    this.state.project_submission = evaluation;

    // Upgrade skills in user profile
    for (const skill of unlocked) {
      const existing = this.state.skills.find(s => s.skill_name.toLowerCase() === skill.toLowerCase());
      if (existing) {
        existing.status = "demonstrated";
        existing.level = "intermediate";
      } else {
        this.state.skills.push({
          skill_name: skill,
          level: "intermediate",
          status: "demonstrated",
          source: "project_eval"
        });
      }
    }

    this.saveState();
    return evaluation;
  }

  applyJob(jobId) {
    this.state.applications[jobId] = "Applied";
    this.saveState();
  }
}

// Global store instance
window.elevoraStore = new ElevoraStore();
